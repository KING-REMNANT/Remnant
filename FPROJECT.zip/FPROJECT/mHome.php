

 <!DOCTYPE html>
 <html lang="en" dir="ltr">
   <head>
<link rel="stylesheet" type="text/css" href="style2.css">


     <meta charset="utf-8">
     <title>Home Page</title>

   </head>
   <body>


     <h1 >
        <div class="image"></div><img src="logo.png" width="100" height="100">WELCOME TO THE KING'S DISHES
      </h1>
      <div class="slider">
         <h2>
<form action="action_handler.php" method="get">
 
  <div class="row">
  <div class="column">
    <div class="image1"></div><img src="backed-beans.jpg" width="300px" height="300px"><br><input type="checkbox" value="1" name="choice[]"> BACKED BEANS:KSH.480
   </div>

<div class="column">
    <div class="image1"></div><img src="Fried-chicken.jpg" width="300px" height="300px"><br> <input type="checkbox" value="2 " name="choice[]"> FRIED CHICKEN:KSH.1600 
</div>

 <div class="column">
          <div class="image1"></div><img src="sea-food.jpg" width="300px" height="300px"><br><input type="checkbox" value="3" name="choice[]">SEA FOOD:KSH.2100
   </div>

  <div class="column">
    <div class="image1"></div><img src="Kerala-beef-fry.jpg" width="300px" height="300px"><br><input type="checkbox" value="4" name="choice[]"> KERALA BEEF FRY:KSH.1900
  </div>

  <div class="column">
    <div class="image1"></div><img src="low-calorie-soup.jpg" width="300px" height="300px"> <br> <input type="checkbox" value="5" name="choice[]"> LOW CALORIE SOUP:KSH.500 
 </div>

   <div class="column">
     <div class="image1"></div><img src="pork-cary.jpg" width="300px" height="300px"><br><input type="checkbox" value="6" name="choice[]"> PORK CARY:KSH.1400 
  </div>

    <div class="column">
      <div class="image1"></div><img src="red-kidney-beans.jpg" width="300px" height="300px"><br> <input type="checkbox" value="7" name="choice[]">RED KIDNEY BEANS:KSH.900
     </div>

       <div class="column">
          <div class="image1"></div><img src="Beef-Fried-Rice.jpg" width="300px" height="300px"><br><input type="checkbox" value="8" name="choice[]">BEEF FRIED RICE: KSH.780
      </div>

        <div class="column">
          <div class="image1"></div><img src="sashimi-plate.jpg" width="300px" height="300px"><br><input type="checkbox" value="9" name="choice[]">SASHIMI: KSH.2000
        </div>
  
  <div class="column">
          <div class="image1"></div><img src="Samaki.jpg" width="300px" height="300px"><br><input type="checkbox" value="10" name="choice[]">SAMAKI:KSH.1150
  </div>

     <div class="column">
          <div class="image1"></div><img src="omena1.jpg" width="300px" height="300px"><br><input type="checkbox" value="11" name="choice[]">OMENA: KSH.760
     </div>

        <div class="column">
          <div class="image1"></div><img src="ugali.jpg" width="300px" height="300px"><br> <input type="checkbox" value="12" name="choice[]">UGALI:KSH.250
           <br>
           <br>
           <input type="submit" value="ORDER THE SELECTED ITEMS" name="" >
       </div>
</div>
</div>
</h2>
</form>

 </div>

   </body>



 </html>
