<!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
  <title></title>

  <style type="text/css">
    table
    {
      border-collapse: collapse;
      width: 100%;
      color: blue;
      font-family: monospace;
      font-size: 20px;
      text-align: left;

    }
    th
    {
      background-color: black;
      color: white;
      padding-right: 100px;
    }
    tr:nth-child(even)
    {
      background-color: green;
    }
   
  </style>

</head>
<body>

<table>
  <tr>
    <th>ID</th>
    <th>FOOD_TYPE</th>
    <th>PRICE</th>
  </tr>

  <?php
  $conn = mysqli_connect("localhost","root","Remnant-123","userregistration"); 
if ($conn -> connect_error) {
  die("condition failed:". $conn -> connect_error);
}

$sql = "SELECT * FROM  tbl_product";
$result = $conn-> query($sql);
if ($result -> num_rows > 0)
 {
  while ($row = $result-> fetch_assoc()) {
    echo "<tr><td>".$row["ID"]. "</td><td>".$row["FOOD_TYPE"]."</td><td>".$row["PRICE"]."</td></tr>";
    # code...
  }
  echo "</table>";
  # code...
}
else
{
  echo "0 result";
}
$conn->close();
   ?>
</table>
</body>
</html>