
<html>
<head>
	<meta charset="utf-8">
	<title></title>
	<style type="text/css">
		 table
    {
      border-collapse: collapse;
      width: 100%;
      color: blue;
      font-family: monospace;
      font-size: 20px;
      text-align: left;

    }

	</style>
	
</head>
<body>
	<table>
		<tr>
    <h1>YOU HAVE ORDERED THE FOLLOWING ITEMS:<br></h1>
    <th>TYPES OF FOOD ORDERED</th>
    <th>AMOUNT IN KSH.</th>
 
  </tr>

<?php 
if(isset($_GET["choice"]))
	

{
	//echo "YOU HAVE ORDERED THE FOLLOWING ITEMS:<br>";
	$food=$_GET["choice"];
	$coun=count($food);

	$price=0.0;


	for($i=0; $i<$coun;$i++)
	{
		if ($food[$i]==1)
		 {

		 	$price=$price+480;
		echo " <td> BACKED BEANS:--------------------------------KSH.480<br>";
			
		}


		if ($food[$i]==2)
		 {
		 	$price=$price+1600;
			echo "FRIED CHICKEN:----------------------------:KSH.1600<br>";
			
		}


		if ($food[$i]==3)
		 {
		 	$price=$price+2100;
			echo "SEA FOOD:---------------------------------KSH.2100<br>";
			
		}

		if ($food[$i]==4)
		 {
		 	$price=$price+1900;
			echo "KERALA BEEF FRY---------------------------KSH.1900<br>";
		
		}

		if ($food[$i]==5)
		 {
		 	$price=$price+500;
			echo "LOW CALORIE SOUP:-------------------------KSH.500<br>";

		}

		if ($food[$i]==6)
		 {
		 	$price=$price+1400;
			echo "PORK CARY:---------------------------------KSH.1400<br>";
		}

		if ($food[$i]==7)
		 {
		 	$price=$price+900;
			echo "RED KIDNEY BEANS:-------------------------KSH.900<br>";
		}

		if ($food[$i]==8)
		 {
		 	$price=$price+780;
			echo "BEEF FRIED RICE:-------------------------KSH.780<br>";
		}

		if ($food[$i]==9)
		 {
		 	$price=$price+2000;
			echo "SHASHIMI:--------------------------------KSH.2000<br>";
		}

		if ($food[$i]==10)
		 {
		 	$price=$price+11500;
			echo "SAMAKI:----------------------------------KSH.1150<br>";
		}

		if ($food[$i]==11)
		 {
		 	$price=$price+760;
			echo "OMENA:----------------------------------KSH.760<br>";
		}

		if ($food[$i]==12)
		 {
		 	$price=$price+250;
			echo "UGALI:----------------------------------KSH.250<br>";
		}

	}
	echo "THE TOTAL COST OF YOUR ORDER IS:<br> KSH.".$price;
}

	
else
	{
		
		echo "Sorry you have not selected any order";
		
	}
 ?>
 </table>
</body>
</html>



