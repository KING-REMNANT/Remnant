<?php
session_start();
header('location:mHome.php');
$con=mysqli_connect('localhost','root','Remnant-123');
mysqli_select_db($con,'userregistration');
$name=$_POST['Username'];
$pass=$_POST['password'];
$s="select*from usertable where name='$name',password='$pass'";
$result= mysqli_query($con,$s);
$num=mysqli_num_rows($result);
if ($num==1)
 {
  
}
else {

}
 ?>
