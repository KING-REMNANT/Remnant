﻿Imports FontAwesome.Sharp
Public Class WELCOME_TO_DTTRS
    Private currentBtn As IconButton
    Private leftBorderBtn As Panel
    Private currentchildform As Form
    Private Sub LblFullScreen_Click(sender As Object, e As EventArgs)
        FormBorderStyle = FormBorderStyle.None
    End Sub
    Public Sub New()
        InitializeComponent()
        leftBorderBtn = New Panel()
        leftBorderBtn.Size = New Size(7, 60)
        Panelmenu.Controls.Add(leftBorderBtn)
    End Sub
    'methods
    Private Sub activateBtn(senderBtn As Object, customcolors As Color)
        If senderBtn IsNot Nothing Then
            disableButton()
            'button
            currentBtn = CType(senderBtn, IconButton)
            currentBtn.BackColor = Color.FromArgb(37, 36, 81)
            currentBtn.ForeColor = customcolors
            currentBtn.IconColor = customcolors
            currentBtn.TextAlign = ContentAlignment.MiddleCenter
            currentBtn.ImageAlign = ContentAlignment.MiddleRight
            currentBtn.TextImageRelation = TextImageRelation.TextBeforeImage
            'left border
            leftBorderBtn.BackColor = customcolors
            leftBorderBtn.Location = New Point(0, currentBtn.Location.Y)
            leftBorderBtn.BringToFront()
            'currentBtn form-home icon
            IconcurrentHome.IconChar = currentBtn.IconChar
            IconcurrentHome.IconColor = customcolors
        End If
    End Sub
    Private Sub disableButton()
        If currentBtn IsNot Nothing Then
            currentBtn.BackColor = Color.FromArgb(31, 30, 68)
            currentBtn.ForeColor = Color.Gainsboro
            currentBtn.IconColor = Color.Gainsboro
            currentBtn.TextAlign = ContentAlignment.MiddleLeft
            currentBtn.ImageAlign = ContentAlignment.MiddleLeft
            currentBtn.TextImageRelation = TextImageRelation.ImageBeforeText
        End If
    End Sub
    'open fonly
    Private Sub openChildForm(childForm As Form)
        If currentchildform IsNot Nothing Then
            currentchildform.Close()
        End If
        currentchildform = childForm
        'end
        childForm.TopLevel = False
        childForm.FormBorderStyle = FormBorderStyle.None
        childForm.Dock = DockStyle.Fill
        PanelDesktop.Controls.Add(childForm)
        PanelDesktop.Tag = childForm
        childForm.BringToFront()
        childForm.Show()
        LblFormTile.Text = childForm.Text
    End Sub
    'event
    Private Sub btnDASHBOAD_Click(sender As Object, e As EventArgs) Handles btnDASHBOAD.Click
        activateBtn(sender, RGBColors.color1)
        openChildForm(New FrmDashBoard)
    End Sub
    Private Sub BtnhomePage_Click(sender As Object, e As EventArgs) Handles BtnhomePage.Click
        activateBtn(sender, RGBColors.color2)
        openChildForm(New FrmHomepage)
    End Sub

    Private Sub BtnView_Click(sender As Object, e As EventArgs) Handles BtnView.Click
        activateBtn(sender, RGBColors.color3)
        openChildForm(New FrmDIAGNOSIS)
    End Sub

    Private Sub BtnOperations_Click(sender As Object, e As EventArgs) Handles BtnLogIn.Click
        activateBtn(sender, RGBColors.color4)
        openChildForm(New Login_form)
    End Sub
    Private Sub BtnPrint_Click(sender As Object, e As EventArgs) Handles BtnPrint.Click
        activateBtn(sender, RGBColors.color5)
        openChildForm(New FrmPrint)
    End Sub
    Private Sub btnsetting_Click(sender As Object, e As EventArgs) Handles btnsetting.Click
        activateBtn(sender, RGBColors.color6)
        openChildForm(New FrmSetting)
    End Sub
    Private Sub reset()
        disableButton()
        leftBorderBtn.Visible = False
        IconcurrentHome.IconChar = IconChar.Home
        IconcurrentHome.IconColor = Color.MediumPurple
        LblFormTile.Text = "Home"
    End Sub

    Private Sub imageHome_Click(sender As Object, e As EventArgs) Handles imageHome.Click
        If currentchildform IsNot Nothing Then
            currentchildform.Close()
        End If
    End Sub

    Private Sub WELCOME_TO_DTTRS_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Start()
        TextBox1.Left = Me.Width

    End Sub

    Private Sub ButtonX_Click(sender As Object, e As EventArgs) Handles ButtonX.Click
        ButtonX.Text = "X"
        Application.Exit()
    End Sub
    Private Sub ButtonX_Enter(sender As Object, e As EventArgs) Handles ButtonX.Enter
        ButtonX.ForeColor = Color.Red
        ButtonX.BackColor = Color.White
    End Sub
    Private Sub ButtonX_Leave(sender As Object, e As EventArgs) Handles ButtonX.Leave
        ButtonX.ForeColor = Color.White
        ButtonX.BackColor = Color.Black
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        TextBox1.Left -= 5
        If TextBox1.Right = Left Then
            TextBox1.Left = Me.Width
        End If
    End Sub
End Class