﻿
Public Class FrmDIAGNOSIS


    Private Sub Button1SEND_Click(sender As Object, e As EventArgs) Handles Button1SEND.Click

    End Sub

    Private Sub CheckBox7_MouseEnter(sender As Object, e As EventArgs) Handles CheckBoxaches.MouseEnter
        PictureBox1AcheandPain.Visible = True


    End Sub

    Private Sub FrmDIAGNOSIS_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        PictureBox1AcheandPain.Visible = False
        PictureBox1CONJUNCTIVITIS.Visible = False
        PictureBox1fatigue.Visible = False
        TextBoxfever.Visible = False
        PictureBox1rushes.Visible = False
    End Sub

    Private Sub CheckBox7_MouseLeave(sender As Object, e As EventArgs) Handles CheckBoxaches.MouseLeave
        PictureBox1AcheandPain.Visible = False

    End Sub

    Private Sub CheckBox3_MouseEnter(sender As Object, e As EventArgs) Handles CheckBoxconjunctivitis.MouseEnter
        PictureBox1CONJUNCTIVITIS.Visible = True
    End Sub

    Private Sub CheckBox3_MouseLeave(sender As Object, e As EventArgs) Handles CheckBoxconjunctivitis.MouseLeave
        PictureBox1CONJUNCTIVITIS.Visible = False
    End Sub

    Private Sub CheckBox16_MouseEnter(sender As Object, e As EventArgs) Handles CheckBoxFatigue.MouseEnter
        PictureBox1fatigue.Visible = True
    End Sub

    Private Sub CheckBox16_MouseLeave(sender As Object, e As EventArgs) Handles CheckBoxFatigue.MouseLeave
        PictureBox1fatigue.Visible = False
    End Sub

    Private Sub CheckBoxfever_MouseEnter(sender As Object, e As EventArgs) Handles CheckBoxfever.MouseEnter
        TextBoxfever.Visible = True

    End Sub

    Private Sub CheckBoxfever_MouseLeave(sender As Object, e As EventArgs) Handles CheckBoxfever.MouseLeave
        TextBoxfever.Visible = False
    End Sub

    Private Sub CheckBox9_MouseEnter(sender As Object, e As EventArgs) Handles CheckBox9.MouseEnter
        PictureBox1rushes.Visible = True
    End Sub

    Private Sub CheckBox9_MouseLeave(sender As Object, e As EventArgs) Handles CheckBox9.MouseLeave
        PictureBox1rushes.Visible = False
    End Sub
End Class