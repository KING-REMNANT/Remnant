﻿Imports MySql.Data.MySqlClient
Public Class Login_form
    Private Sub Login_form_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Panel1.BackColor = Color.FromArgb(120, 0, 0, 0)
        ' transparent blue background for panel3
        Panel2.BackColor = Color.FromArgb(100, 17, 97, 238)
        ButtonClose.BackColor = Color.FromArgb(100, 0, 0, 0)
    End Sub

    Private Sub ButtonClose_MouseEnter(sender As Object, e As EventArgs) Handles ButtonClose.MouseEnter
        ButtonClose.ForeColor = Color.White
    End Sub

    Private Sub ButtonClose_DragLeave(sender As Object, e As EventArgs)
        ButtonClose.ForeColor = Color.LightGray
    End Sub

    Private Sub ButtonClose_Click(sender As Object, e As EventArgs)
        Application.Exit()
    End Sub
    Private Sub TextBoxUSERNAME_Enter(sender As Object, e As EventArgs) Handles TextBoxUSERNAME.Enter

        ' clear the textbox when the textbox get the focus
        Dim username As String = TextBoxUSERNAME.Text
        ' check if the username is empty
        ' check if the textbox contains the default value "username"
        If username.Trim().ToLower() = "username" Or username.Trim() = "" Then

            ' clear the textbox
            TextBoxUSERNAME.Text = ""
            ' change the textbox for color
            TextBoxUSERNAME.ForeColor = Color.Green
        End If

    End Sub

    Private Sub TextBoxUSERNAME_Leave(sender As Object, e As EventArgs) Handles TextBoxUSERNAME.Leave

        ' when the textbox get lost the focus
        Dim username As String = TextBoxUSERNAME.Text
        ' check if the username is empty
        ' check if the textbox contains the default value "username"
        If username.Trim().ToLower() = "username" Or username.Trim() = "" Then

            ' set the textbox text
            TextBoxUSERNAME.Text = "username"
            ' change the textbox for color
            TextBoxUSERNAME.ForeColor = Color.DarkGray

        End If
    End Sub
    Private Sub TextBoxPASSWORD_Enter_1(sender As Object, e As EventArgs) Handles TextBoxPASSWORD.Enter
        Dim password As String = TextBoxPASSWORD.Text
        If password.Trim().ToLower() = "password" Or password.Trim() = "" Then

            ' set the textbox text
            TextBoxPASSWORD.Text = ""
            ' change the textbox font color
            TextBoxPASSWORD.ForeColor = Color.DarkGray
            ' set system password to false
            TextBoxPASSWORD.UseSystemPasswordChar = True

        End If


    End Sub

    Private Sub TextBoxPASSWORD_Leave_1(sender As Object, e As EventArgs) Handles TextBoxPASSWORD.Leave

        ' when textbox password lost focus
        Dim password As String = TextBoxPASSWORD.Text
        If password.Trim().ToLower() = "password" Or password.Trim() = "" Then

            ' set the textbox text
            TextBoxPASSWORD.Text = "password"
            ' change the textbox font color
            TextBoxPASSWORD.ForeColor = Color.DarkGray
            ' set system password to false
            TextBoxPASSWORD.UseSystemPasswordChar = False
        End If
    End Sub
    Private Sub Button1LOGIN_Click_1(sender As Object, e As EventArgs) Handles Button1LOGIN.Click
        Try
            Dim conn As New MY_CONNECTION()
            Dim adapter As New MySqlDataAdapter()
            Dim table As New DataTable()
            Dim command As New MySqlCommand("SELECT `USERNAME`, `PASSWORD` FROM `user` WHERE `USERNAME`=@username and `PASSWORD`=@password", conn.getConnection())

            command.Parameters.Add("@username", MySqlDbType.VarChar).Value = TextBoxUSERNAME.Text
            command.Parameters.Add("@password", MySqlDbType.VarChar).Value = TextBoxPASSWORD.Text

            If TextBoxUSERNAME.Text.Trim() = "" Or TextBoxUSERNAME.Text.Trim().ToLower() = "username" Then

                MessageBox.Show("Enter Your Username To Login", "Missing Username", MessageBoxButtons.OK, MessageBoxIcon.Error)

            ElseIf TextBoxPASSWORD.Text.Trim() = "" Or TextBoxPASSWORD.Text.Trim().ToLower() = "password" Then

                MessageBox.Show("Enter Your Password To Login", "Missing Password", MessageBoxButtons.OK, MessageBoxIcon.Error)

            Else

                adapter.SelectCommand = command
                adapter.Fill(table)

                If table.Rows.Count > 0 Then


                    Me.Hide()
                    Dim mainAppForm As New WELCOME_TO_DTTRS()
                    WELCOME_TO_DTTRS.Show()

                Else

                    MessageBox.Show("This Username Or/And Password Doesn't Exists", "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                End If

            End If
        Catch ex As Exception
            MessageBox.Show("Check your Server connection", "Server Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try





    End Sub

    Private Sub LabelGoToSignUP_Click(sender As Object, e As EventArgs) Handles LabelGoToSignUP.Click
        Me.Hide()
        registerForm.Show()

    End Sub
End Class




