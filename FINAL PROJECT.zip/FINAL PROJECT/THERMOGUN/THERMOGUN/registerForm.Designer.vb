﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class registerForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.LabelGoToSignIn = New System.Windows.Forms.Label()
        Me.TextBoxusername = New System.Windows.Forms.TextBox()
        Me.LabelSurname = New System.Windows.Forms.Label()
        Me.LabelUserName = New System.Windows.Forms.Label()
        Me.LabelPASS2 = New System.Windows.Forms.Label()
        Me.TextBoxSurname = New System.Windows.Forms.TextBox()
        Me.TextBoxConfirmPassword = New System.Windows.Forms.TextBox()
        Me.TextBoxEmail = New System.Windows.Forms.TextBox()
        Me.LabelPASSWORD1 = New System.Windows.Forms.Label()
        Me.LabelFname = New System.Windows.Forms.Label()
        Me.TextBoxFirstname = New System.Windows.Forms.TextBox()
        Me.LabelEmail = New System.Windows.Forms.Label()
        Me.TextBoxpassword = New System.Windows.Forms.TextBox()
        Me.Buttonregister = New System.Windows.Forms.Button()
        Me.ButtonClose = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.Panel1.Controls.Add(Me.LabelGoToSignIn)
        Me.Panel1.Controls.Add(Me.TextBoxusername)
        Me.Panel1.Controls.Add(Me.LabelSurname)
        Me.Panel1.Controls.Add(Me.LabelUserName)
        Me.Panel1.Controls.Add(Me.LabelPASS2)
        Me.Panel1.Controls.Add(Me.TextBoxSurname)
        Me.Panel1.Controls.Add(Me.TextBoxConfirmPassword)
        Me.Panel1.Controls.Add(Me.TextBoxEmail)
        Me.Panel1.Controls.Add(Me.LabelPASSWORD1)
        Me.Panel1.Controls.Add(Me.LabelFname)
        Me.Panel1.Controls.Add(Me.TextBoxFirstname)
        Me.Panel1.Controls.Add(Me.LabelEmail)
        Me.Panel1.Controls.Add(Me.TextBoxpassword)
        Me.Panel1.Controls.Add(Me.Buttonregister)
        Me.Panel1.Controls.Add(Me.ButtonClose)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Location = New System.Drawing.Point(12, 10)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(629, 467)
        Me.Panel1.TabIndex = 19
        '
        'LabelGoToSignIn
        '
        Me.LabelGoToSignIn.AutoSize = True
        Me.LabelGoToSignIn.Location = New System.Drawing.Point(250, 440)
        Me.LabelGoToSignIn.Name = "LabelGoToSignIn"
        Me.LabelGoToSignIn.Size = New System.Drawing.Size(104, 13)
        Me.LabelGoToSignIn.TabIndex = 33
        Me.LabelGoToSignIn.Text = "Click Here to Sign In"
        '
        'TextBoxusername
        '
        Me.TextBoxusername.Location = New System.Drawing.Point(211, 162)
        Me.TextBoxusername.Name = "TextBoxusername"
        Me.TextBoxusername.Size = New System.Drawing.Size(282, 20)
        Me.TextBoxusername.TabIndex = 25
        '
        'LabelSurname
        '
        Me.LabelSurname.AutoSize = True
        Me.LabelSurname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelSurname.ForeColor = System.Drawing.Color.White
        Me.LabelSurname.Location = New System.Drawing.Point(24, 129)
        Me.LabelSurname.Name = "LabelSurname"
        Me.LabelSurname.Size = New System.Drawing.Size(89, 16)
        Me.LabelSurname.TabIndex = 24
        Me.LabelSurname.Text = "*SURNAME"
        '
        'LabelUserName
        '
        Me.LabelUserName.AutoSize = True
        Me.LabelUserName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelUserName.ForeColor = System.Drawing.Color.White
        Me.LabelUserName.Location = New System.Drawing.Point(21, 176)
        Me.LabelUserName.Name = "LabelUserName"
        Me.LabelUserName.Size = New System.Drawing.Size(103, 16)
        Me.LabelUserName.TabIndex = 26
        Me.LabelUserName.Text = "*USER NAME"
        '
        'LabelPASS2
        '
        Me.LabelPASS2.AutoSize = True
        Me.LabelPASS2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelPASS2.ForeColor = System.Drawing.Color.White
        Me.LabelPASS2.Location = New System.Drawing.Point(24, 291)
        Me.LabelPASS2.Name = "LabelPASS2"
        Me.LabelPASS2.Size = New System.Drawing.Size(173, 16)
        Me.LabelPASS2.TabIndex = 32
        Me.LabelPASS2.Text = "*CONFIRM PASSWORD"
        '
        'TextBoxSurname
        '
        Me.TextBoxSurname.Location = New System.Drawing.Point(211, 122)
        Me.TextBoxSurname.Name = "TextBoxSurname"
        Me.TextBoxSurname.Size = New System.Drawing.Size(282, 20)
        Me.TextBoxSurname.TabIndex = 23
        '
        'TextBoxConfirmPassword
        '
        Me.TextBoxConfirmPassword.Location = New System.Drawing.Point(210, 284)
        Me.TextBoxConfirmPassword.Name = "TextBoxConfirmPassword"
        Me.TextBoxConfirmPassword.Size = New System.Drawing.Size(283, 20)
        Me.TextBoxConfirmPassword.TabIndex = 31
        '
        'TextBoxEmail
        '
        Me.TextBoxEmail.Location = New System.Drawing.Point(210, 204)
        Me.TextBoxEmail.Name = "TextBoxEmail"
        Me.TextBoxEmail.Size = New System.Drawing.Size(283, 20)
        Me.TextBoxEmail.TabIndex = 27
        '
        'LabelPASSWORD1
        '
        Me.LabelPASSWORD1.AutoSize = True
        Me.LabelPASSWORD1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelPASSWORD1.ForeColor = System.Drawing.Color.White
        Me.LabelPASSWORD1.Location = New System.Drawing.Point(24, 246)
        Me.LabelPASSWORD1.Name = "LabelPASSWORD1"
        Me.LabelPASSWORD1.Size = New System.Drawing.Size(157, 16)
        Me.LabelPASSWORD1.TabIndex = 30
        Me.LabelPASSWORD1.Text = "*ENTER PASSWORD"
        '
        'LabelFname
        '
        Me.LabelFname.AutoSize = True
        Me.LabelFname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelFname.ForeColor = System.Drawing.Color.White
        Me.LabelFname.Location = New System.Drawing.Point(20, 95)
        Me.LabelFname.Name = "LabelFname"
        Me.LabelFname.Size = New System.Drawing.Size(105, 16)
        Me.LabelFname.TabIndex = 22
        Me.LabelFname.Text = "*FIRST NAME"
        '
        'TextBoxFirstname
        '
        Me.TextBoxFirstname.Location = New System.Drawing.Point(211, 81)
        Me.TextBoxFirstname.Name = "TextBoxFirstname"
        Me.TextBoxFirstname.Size = New System.Drawing.Size(282, 20)
        Me.TextBoxFirstname.TabIndex = 21
        '
        'LabelEmail
        '
        Me.LabelEmail.AutoSize = True
        Me.LabelEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelEmail.ForeColor = System.Drawing.Color.White
        Me.LabelEmail.Location = New System.Drawing.Point(24, 211)
        Me.LabelEmail.Name = "LabelEmail"
        Me.LabelEmail.Size = New System.Drawing.Size(58, 16)
        Me.LabelEmail.TabIndex = 28
        Me.LabelEmail.Text = "*EMAIL"
        '
        'TextBoxpassword
        '
        Me.TextBoxpassword.Location = New System.Drawing.Point(210, 243)
        Me.TextBoxpassword.Name = "TextBoxpassword"
        Me.TextBoxpassword.Size = New System.Drawing.Size(283, 20)
        Me.TextBoxpassword.TabIndex = 29
        '
        'Buttonregister
        '
        Me.Buttonregister.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Buttonregister.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Buttonregister.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Buttonregister.Location = New System.Drawing.Point(27, 359)
        Me.Buttonregister.Name = "Buttonregister"
        Me.Buttonregister.Size = New System.Drawing.Size(538, 56)
        Me.Buttonregister.TabIndex = 18
        Me.Buttonregister.Text = "SIGN UP"
        Me.Buttonregister.UseVisualStyleBackColor = False
        '
        'ButtonClose
        '
        Me.ButtonClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonClose.ForeColor = System.Drawing.Color.Maroon
        Me.ButtonClose.Location = New System.Drawing.Point(554, 0)
        Me.ButtonClose.Name = "ButtonClose"
        Me.ButtonClose.Size = New System.Drawing.Size(75, 73)
        Me.ButtonClose.TabIndex = 16
        Me.ButtonClose.Text = "X"
        Me.ButtonClose.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(97, Byte), Integer), CType(CType(238, Byte), Integer))
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(629, 73)
        Me.Panel2.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.Font = New System.Drawing.Font("Microsoft YaHei", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(203, 7)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(190, 46)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "REGISTER"
        '
        'registerForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkSlateGray
        Me.ClientSize = New System.Drawing.Size(653, 488)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "registerForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "registerForm"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents TextBoxusername As TextBox
    Friend WithEvents LabelSurname As Label
    Friend WithEvents LabelUserName As Label
    Friend WithEvents LabelPASS2 As Label
    Friend WithEvents TextBoxSurname As TextBox
    Friend WithEvents TextBoxConfirmPassword As TextBox
    Friend WithEvents TextBoxEmail As TextBox
    Friend WithEvents LabelPASSWORD1 As Label
    Friend WithEvents LabelFname As Label
    Friend WithEvents TextBoxFirstname As TextBox
    Friend WithEvents LabelEmail As Label
    Friend WithEvents TextBoxpassword As TextBox
    Friend WithEvents Buttonregister As Button
    Friend WithEvents ButtonClose As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents LabelGoToSignIn As Label
End Class
