﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmHomepage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim GENDERLabel As System.Windows.Forms.Label
        Dim ID_NUMBERLabel As System.Windows.Forms.Label
        Dim AGELabel As System.Windows.Forms.Label
        Dim TEMPERATURELabel As System.Windows.Forms.Label
        Dim COUNTYLabel As System.Windows.Forms.Label
        Dim PHONE_NOLabel As System.Windows.Forms.Label
        Dim SURNAMELabel As System.Windows.Forms.Label
        Dim FIRST_NAMELabel As System.Windows.Forms.Label
        Me.Panel1Homepage = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Buttonnormal = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.GENDERcomboBox = New System.Windows.Forms.ComboBox()
        Me.COUNTYcomboBox = New System.Windows.Forms.ComboBox()
        Me.AGETextBox = New System.Windows.Forms.TextBox()
        Me.TEMPERATURETextBox = New System.Windows.Forms.TextBox()
        Me.ID_NUMBERTextBox = New System.Windows.Forms.TextBox()
        Me.SURNAMETextBox = New System.Windows.Forms.TextBox()
        Me.PHONE_NOTextBox = New System.Windows.Forms.TextBox()
        Me.FIRST_NAMETextBox = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.CheckBoxByID = New System.Windows.Forms.CheckBox()
        Me.CheckBoxByName = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ButtonVIEW = New System.Windows.Forms.Button()
        Me.TextBox1Search = New System.Windows.Forms.TextBox()
        Me.Buttonhigh = New System.Windows.Forms.Button()
        Me.ButtonMedium = New System.Windows.Forms.Button()
        Me.ButtonDELETE = New System.Windows.Forms.Button()
        Me.ButtonREFRESH = New System.Windows.Forms.Button()
        Me.Buttonclear = New System.Windows.Forms.Button()
        Me.ButtonEDIT = New System.Windows.Forms.Button()
        Me.ButtonSave = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.DeleteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DELETEToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.EDITToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SELECTALLToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        GENDERLabel = New System.Windows.Forms.Label()
        ID_NUMBERLabel = New System.Windows.Forms.Label()
        AGELabel = New System.Windows.Forms.Label()
        TEMPERATURELabel = New System.Windows.Forms.Label()
        COUNTYLabel = New System.Windows.Forms.Label()
        PHONE_NOLabel = New System.Windows.Forms.Label()
        SURNAMELabel = New System.Windows.Forms.Label()
        FIRST_NAMELabel = New System.Windows.Forms.Label()
        Me.Panel1Homepage.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GENDERLabel
        '
        GENDERLabel.AutoSize = True
        GENDERLabel.Location = New System.Drawing.Point(-1, 391)
        GENDERLabel.Name = "GENDERLabel"
        GENDERLabel.Size = New System.Drawing.Size(56, 13)
        GENDERLabel.TabIndex = 31
        GENDERLabel.Text = "GENDER:"
        '
        'ID_NUMBERLabel
        '
        ID_NUMBERLabel.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        ID_NUMBERLabel.AutoSize = True
        ID_NUMBERLabel.Location = New System.Drawing.Point(-1, 83)
        ID_NUMBERLabel.Name = "ID_NUMBERLabel"
        ID_NUMBERLabel.Size = New System.Drawing.Size(71, 13)
        ID_NUMBERLabel.TabIndex = 18
        ID_NUMBERLabel.Text = "ID NUMBER:"
        '
        'AGELabel
        '
        AGELabel.AutoSize = True
        AGELabel.Location = New System.Drawing.Point(-1, 365)
        AGELabel.Name = "AGELabel"
        AGELabel.Size = New System.Drawing.Size(32, 13)
        AGELabel.TabIndex = 29
        AGELabel.Text = "AGE:"
        '
        'TEMPERATURELabel
        '
        TEMPERATURELabel.AutoSize = True
        TEMPERATURELabel.Location = New System.Drawing.Point(-1, 304)
        TEMPERATURELabel.Name = "TEMPERATURELabel"
        TEMPERATURELabel.Size = New System.Drawing.Size(92, 13)
        TEMPERATURELabel.TabIndex = 27
        TEMPERATURELabel.Text = "TEMPERATURE:"
        '
        'COUNTYLabel
        '
        COUNTYLabel.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        COUNTYLabel.AutoSize = True
        COUNTYLabel.Location = New System.Drawing.Point(-1, 278)
        COUNTYLabel.Name = "COUNTYLabel"
        COUNTYLabel.Size = New System.Drawing.Size(55, 13)
        COUNTYLabel.TabIndex = 26
        COUNTYLabel.Text = "COUNTY:"
        '
        'PHONE_NOLabel
        '
        PHONE_NOLabel.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        PHONE_NOLabel.AutoSize = True
        PHONE_NOLabel.Location = New System.Drawing.Point(-1, 109)
        PHONE_NOLabel.Name = "PHONE_NOLabel"
        PHONE_NOLabel.Size = New System.Drawing.Size(67, 13)
        PHONE_NOLabel.TabIndex = 20
        PHONE_NOLabel.Text = "PHONE NO:"
        '
        'SURNAMELabel
        '
        SURNAMELabel.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        SURNAMELabel.AutoSize = True
        SURNAMELabel.Location = New System.Drawing.Point(-1, 200)
        SURNAMELabel.Name = "SURNAMELabel"
        SURNAMELabel.Size = New System.Drawing.Size(64, 13)
        SURNAMELabel.TabIndex = 24
        SURNAMELabel.Text = "SURNAME:"
        '
        'FIRST_NAMELabel
        '
        FIRST_NAMELabel.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        FIRST_NAMELabel.AutoSize = True
        FIRST_NAMELabel.Location = New System.Drawing.Point(-1, 174)
        FIRST_NAMELabel.Name = "FIRST_NAMELabel"
        FIRST_NAMELabel.Size = New System.Drawing.Size(75, 13)
        FIRST_NAMELabel.TabIndex = 22
        FIRST_NAMELabel.Text = "FIRST NAME:"
        '
        'Panel1Homepage
        '
        Me.Panel1Homepage.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1Homepage.Controls.Add(Me.Label2)
        Me.Panel1Homepage.Controls.Add(Me.Buttonnormal)
        Me.Panel1Homepage.Controls.Add(Me.Panel1)
        Me.Panel1Homepage.Controls.Add(Me.GroupBox1)
        Me.Panel1Homepage.Controls.Add(Me.MenuStrip1)
        Me.Panel1Homepage.Location = New System.Drawing.Point(0, 0)
        Me.Panel1Homepage.Name = "Panel1Homepage"
        Me.Panel1Homepage.Size = New System.Drawing.Size(1149, 528)
        Me.Panel1Homepage.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(977, 44)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 13)
        Me.Label2.TabIndex = 32
        Me.Label2.Text = "NORMAL"
        '
        'Buttonnormal
        '
        Me.Buttonnormal.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Buttonnormal.BackColor = System.Drawing.Color.Green
        Me.Buttonnormal.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Buttonnormal.ForeColor = System.Drawing.Color.White
        Me.Buttonnormal.Location = New System.Drawing.Point(1028, 24)
        Me.Buttonnormal.Name = "Buttonnormal"
        Me.Buttonnormal.Size = New System.Drawing.Size(103, 52)
        Me.Buttonnormal.TabIndex = 31
        Me.Buttonnormal.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel1.Controls.Add(Me.GENDERcomboBox)
        Me.Panel1.Controls.Add(Me.COUNTYcomboBox)
        Me.Panel1.Controls.Add(Me.AGETextBox)
        Me.Panel1.Controls.Add(GENDERLabel)
        Me.Panel1.Controls.Add(ID_NUMBERLabel)
        Me.Panel1.Controls.Add(AGELabel)
        Me.Panel1.Controls.Add(Me.TEMPERATURETextBox)
        Me.Panel1.Controls.Add(Me.ID_NUMBERTextBox)
        Me.Panel1.Controls.Add(TEMPERATURELabel)
        Me.Panel1.Controls.Add(COUNTYLabel)
        Me.Panel1.Controls.Add(PHONE_NOLabel)
        Me.Panel1.Controls.Add(Me.SURNAMETextBox)
        Me.Panel1.Controls.Add(SURNAMELabel)
        Me.Panel1.Controls.Add(Me.PHONE_NOTextBox)
        Me.Panel1.Controls.Add(Me.FIRST_NAMETextBox)
        Me.Panel1.Controls.Add(FIRST_NAMELabel)
        Me.Panel1.Location = New System.Drawing.Point(0, 24)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(263, 504)
        Me.Panel1.TabIndex = 21
        '
        'GENDERcomboBox
        '
        Me.GENDERcomboBox.FormattingEnabled = True
        Me.GENDERcomboBox.Items.AddRange(New Object() {"Male", "Female", "Others"})
        Me.GENDERcomboBox.Location = New System.Drawing.Point(97, 391)
        Me.GENDERcomboBox.Name = "GENDERcomboBox"
        Me.GENDERcomboBox.Size = New System.Drawing.Size(153, 21)
        Me.GENDERcomboBox.TabIndex = 33
        '
        'COUNTYcomboBox
        '
        Me.COUNTYcomboBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.COUNTYcomboBox.FormattingEnabled = True
        Me.COUNTYcomboBox.Items.AddRange(New Object() {"1.Mombasa County", "2.Kwale County", "3.Kilifi County", "4.Tana River County", "5.Lamu County", "6.Taita-Taveta County", "7.Garissa County", "8.Wajir County", "9.Mandera County", "10.Marsabit County", "11.Isiolo County", "12.Meru22 County", "13.Tharaka-Nithi County", "14.Embu County", "15.Kitui County", "16.Machakos County", "17.Makueni County", "18.Nyandarua County", "19.Nyeri County", "20.Kirinyaga County", "21.Murang’a County", "22.Kiambu County", "23.Turkana County", "24.West Pokot County", "25.Samburu County", "26.Trans Nzoia County", "27.Uasin Gishu County", "28.Elgeyo-Marakwet County", "29.Nandi County", "30.Baringo County", "31.Laikipia County", "32.Nakuru County", "33.Narok County", "34.Kajiado County", "35.Kericho County", "36.Bomet County", "37.Kakamega County", "38.Vihiga County", "39.Bungoma County", "40.Busia County", "41.Siaya County", "42.Kisumu County", "43.Homa Bay County", "44.Migori County", "45.Kisii County", "46Nyamira County", "47.Nairobi County"})
        Me.COUNTYcomboBox.Location = New System.Drawing.Point(97, 274)
        Me.COUNTYcomboBox.Name = "COUNTYcomboBox"
        Me.COUNTYcomboBox.Size = New System.Drawing.Size(153, 21)
        Me.COUNTYcomboBox.TabIndex = 32
        '
        'AGETextBox
        '
        Me.AGETextBox.Location = New System.Drawing.Point(97, 362)
        Me.AGETextBox.Name = "AGETextBox"
        Me.AGETextBox.Size = New System.Drawing.Size(153, 20)
        Me.AGETextBox.TabIndex = 30
        '
        'TEMPERATURETextBox
        '
        Me.TEMPERATURETextBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TEMPERATURETextBox.Location = New System.Drawing.Point(97, 301)
        Me.TEMPERATURETextBox.Name = "TEMPERATURETextBox"
        Me.TEMPERATURETextBox.Size = New System.Drawing.Size(153, 20)
        Me.TEMPERATURETextBox.TabIndex = 28
        '
        'ID_NUMBERTextBox
        '
        Me.ID_NUMBERTextBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ID_NUMBERTextBox.Location = New System.Drawing.Point(97, 80)
        Me.ID_NUMBERTextBox.Name = "ID_NUMBERTextBox"
        Me.ID_NUMBERTextBox.Size = New System.Drawing.Size(153, 20)
        Me.ID_NUMBERTextBox.TabIndex = 19
        '
        'SURNAMETextBox
        '
        Me.SURNAMETextBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.SURNAMETextBox.Location = New System.Drawing.Point(97, 197)
        Me.SURNAMETextBox.Name = "SURNAMETextBox"
        Me.SURNAMETextBox.Size = New System.Drawing.Size(153, 20)
        Me.SURNAMETextBox.TabIndex = 25
        '
        'PHONE_NOTextBox
        '
        Me.PHONE_NOTextBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.PHONE_NOTextBox.Location = New System.Drawing.Point(97, 106)
        Me.PHONE_NOTextBox.Name = "PHONE_NOTextBox"
        Me.PHONE_NOTextBox.Size = New System.Drawing.Size(153, 20)
        Me.PHONE_NOTextBox.TabIndex = 21
        '
        'FIRST_NAMETextBox
        '
        Me.FIRST_NAMETextBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.FIRST_NAMETextBox.Location = New System.Drawing.Point(97, 171)
        Me.FIRST_NAMETextBox.Name = "FIRST_NAMETextBox"
        Me.FIRST_NAMETextBox.Size = New System.Drawing.Size(153, 20)
        Me.FIRST_NAMETextBox.TabIndex = 23
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.CheckBoxByID)
        Me.GroupBox1.Controls.Add(Me.CheckBoxByName)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.ButtonVIEW)
        Me.GroupBox1.Controls.Add(Me.TextBox1Search)
        Me.GroupBox1.Controls.Add(Me.Buttonhigh)
        Me.GroupBox1.Controls.Add(Me.ButtonMedium)
        Me.GroupBox1.Controls.Add(Me.ButtonDELETE)
        Me.GroupBox1.Controls.Add(Me.ButtonREFRESH)
        Me.GroupBox1.Controls.Add(Me.Buttonclear)
        Me.GroupBox1.Controls.Add(Me.ButtonEDIT)
        Me.GroupBox1.Controls.Add(Me.ButtonSave)
        Me.GroupBox1.Controls.Add(Me.DataGridView1)
        Me.GroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GroupBox1.Location = New System.Drawing.Point(266, 83)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(871, 442)
        Me.GroupBox1.TabIndex = 19
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "DETAILS"
        '
        'Button1
        '
        Me.Button1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Button1.Location = New System.Drawing.Point(407, 93)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(86, 28)
        Me.Button1.TabIndex = 35
        Me.Button1.Text = "SEARCH"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(730, 83)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(34, 13)
        Me.Label4.TabIndex = 34
        Me.Label4.Text = "HIGH"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(713, 14)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(51, 13)
        Me.Label3.TabIndex = 33
        Me.Label3.Text = "MEDIUM"
        '
        'CheckBoxByID
        '
        Me.CheckBoxByID.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.CheckBoxByID.AutoSize = True
        Me.CheckBoxByID.Location = New System.Drawing.Point(139, 119)
        Me.CheckBoxByID.Name = "CheckBoxByID"
        Me.CheckBoxByID.Size = New System.Drawing.Size(88, 17)
        Me.CheckBoxByID.TabIndex = 30
        Me.CheckBoxByID.Text = "Search by ID"
        Me.CheckBoxByID.UseVisualStyleBackColor = True
        '
        'CheckBoxByName
        '
        Me.CheckBoxByName.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.CheckBoxByName.AutoSize = True
        Me.CheckBoxByName.Location = New System.Drawing.Point(139, 99)
        Me.CheckBoxByName.Name = "CheckBoxByName"
        Me.CheckBoxByName.Size = New System.Drawing.Size(103, 17)
        Me.CheckBoxByName.TabIndex = 29
        Me.CheckBoxByName.Text = "Search by name"
        Me.CheckBoxByName.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(98, 103)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(44, 13)
        Me.Label1.TabIndex = 28
        Me.Label1.Text = "Search "
        '
        'ButtonVIEW
        '
        Me.ButtonVIEW.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ButtonVIEW.Location = New System.Drawing.Point(552, 94)
        Me.ButtonVIEW.Name = "ButtonVIEW"
        Me.ButtonVIEW.Size = New System.Drawing.Size(103, 26)
        Me.ButtonVIEW.TabIndex = 24
        Me.ButtonVIEW.Text = "VIEW"
        Me.ButtonVIEW.UseVisualStyleBackColor = True
        '
        'TextBox1Search
        '
        Me.TextBox1Search.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.TextBox1Search.Location = New System.Drawing.Point(248, 97)
        Me.TextBox1Search.Name = "TextBox1Search"
        Me.TextBox1Search.Size = New System.Drawing.Size(153, 20)
        Me.TextBox1Search.TabIndex = 27
        '
        'Buttonhigh
        '
        Me.Buttonhigh.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Buttonhigh.BackColor = System.Drawing.Color.Red
        Me.Buttonhigh.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Buttonhigh.ForeColor = System.Drawing.Color.White
        Me.Buttonhigh.Location = New System.Drawing.Point(762, 62)
        Me.Buttonhigh.Name = "Buttonhigh"
        Me.Buttonhigh.Size = New System.Drawing.Size(99, 54)
        Me.Buttonhigh.TabIndex = 26
        Me.Buttonhigh.UseVisualStyleBackColor = False
        '
        'ButtonMedium
        '
        Me.ButtonMedium.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ButtonMedium.BackColor = System.Drawing.Color.Orange
        Me.ButtonMedium.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonMedium.ForeColor = System.Drawing.Color.White
        Me.ButtonMedium.Location = New System.Drawing.Point(762, 0)
        Me.ButtonMedium.Name = "ButtonMedium"
        Me.ButtonMedium.Size = New System.Drawing.Size(103, 52)
        Me.ButtonMedium.TabIndex = 25
        Me.ButtonMedium.UseVisualStyleBackColor = False
        '
        'ButtonDELETE
        '
        Me.ButtonDELETE.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.ButtonDELETE.Location = New System.Drawing.Point(222, 6)
        Me.ButtonDELETE.Name = "ButtonDELETE"
        Me.ButtonDELETE.Size = New System.Drawing.Size(86, 28)
        Me.ButtonDELETE.TabIndex = 23
        Me.ButtonDELETE.Text = "DELETE"
        Me.ButtonDELETE.UseVisualStyleBackColor = True
        '
        'ButtonREFRESH
        '
        Me.ButtonREFRESH.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ButtonREFRESH.Location = New System.Drawing.Point(552, 9)
        Me.ButtonREFRESH.Name = "ButtonREFRESH"
        Me.ButtonREFRESH.Size = New System.Drawing.Size(103, 23)
        Me.ButtonREFRESH.TabIndex = 22
        Me.ButtonREFRESH.Text = "REFRESH"
        Me.ButtonREFRESH.UseVisualStyleBackColor = True
        '
        'Buttonclear
        '
        Me.Buttonclear.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Buttonclear.Location = New System.Drawing.Point(404, 9)
        Me.Buttonclear.Name = "Buttonclear"
        Me.Buttonclear.Size = New System.Drawing.Size(79, 28)
        Me.Buttonclear.TabIndex = 21
        Me.Buttonclear.Text = "CLEAR"
        Me.Buttonclear.UseVisualStyleBackColor = True
        '
        'ButtonEDIT
        '
        Me.ButtonEDIT.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.ButtonEDIT.Location = New System.Drawing.Point(10, 94)
        Me.ButtonEDIT.Name = "ButtonEDIT"
        Me.ButtonEDIT.Size = New System.Drawing.Size(75, 28)
        Me.ButtonEDIT.TabIndex = 20
        Me.ButtonEDIT.Text = "EDIT"
        Me.ButtonEDIT.UseVisualStyleBackColor = True
        '
        'ButtonSave
        '
        Me.ButtonSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.ButtonSave.Location = New System.Drawing.Point(6, 17)
        Me.ButtonSave.Name = "ButtonSave"
        Me.ButtonSave.Size = New System.Drawing.Size(79, 35)
        Me.ButtonSave.TabIndex = 19
        Me.ButtonSave.Text = "SAVE"
        Me.ButtonSave.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(6, 141)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.Size = New System.Drawing.Size(859, 288)
        Me.DataGridView1.TabIndex = 18
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DeleteToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1149, 24)
        Me.MenuStrip1.TabIndex = 20
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'DeleteToolStripMenuItem
        '
        Me.DeleteToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DELETEToolStripMenuItem1, Me.EDITToolStripMenuItem, Me.SELECTALLToolStripMenuItem})
        Me.DeleteToolStripMenuItem.Name = "DeleteToolStripMenuItem"
        Me.DeleteToolStripMenuItem.Size = New System.Drawing.Size(46, 20)
        Me.DeleteToolStripMenuItem.Text = "FILES"
        '
        'DELETEToolStripMenuItem1
        '
        Me.DELETEToolStripMenuItem1.Name = "DELETEToolStripMenuItem1"
        Me.DELETEToolStripMenuItem1.Size = New System.Drawing.Size(135, 22)
        Me.DELETEToolStripMenuItem1.Text = "DELETE"
        '
        'EDITToolStripMenuItem
        '
        Me.EDITToolStripMenuItem.Name = "EDITToolStripMenuItem"
        Me.EDITToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.EDITToolStripMenuItem.Text = "EDIT"
        '
        'SELECTALLToolStripMenuItem
        '
        Me.SELECTALLToolStripMenuItem.Name = "SELECTALLToolStripMenuItem"
        Me.SELECTALLToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.SELECTALLToolStripMenuItem.Text = "SELECT ALL"
        '
        'FrmHomepage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1149, 575)
        Me.Controls.Add(Me.Panel1Homepage)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "FrmHomepage"
        Me.Text = "FrmHomepage"
        Me.Panel1Homepage.ResumeLayout(False)
        Me.Panel1Homepage.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1Homepage As Panel
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Buttonhigh As Button
    Friend WithEvents ButtonMedium As Button
    Friend WithEvents ButtonVIEW As Button
    Friend WithEvents ButtonDELETE As Button
    Friend WithEvents ButtonREFRESH As Button
    Friend WithEvents Buttonclear As Button
    Friend WithEvents ButtonEDIT As Button
    Friend WithEvents ButtonSave As Button
    Friend WithEvents TextBox1Search As TextBox
    Friend WithEvents CheckBoxByID As CheckBox
    Friend WithEvents CheckBoxByName As CheckBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents GENDERcomboBox As ComboBox
    Friend WithEvents COUNTYcomboBox As ComboBox
    Friend WithEvents AGETextBox As TextBox
    Friend WithEvents TEMPERATURETextBox As TextBox
    Friend WithEvents ID_NUMBERTextBox As TextBox
    Friend WithEvents SURNAMETextBox As TextBox
    Friend WithEvents PHONE_NOTextBox As TextBox
    Friend WithEvents FIRST_NAMETextBox As TextBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents DeleteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DELETEToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents EDITToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SELECTALLToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Label2 As Label
    Friend WithEvents Buttonnormal As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Button1 As Button
End Class
