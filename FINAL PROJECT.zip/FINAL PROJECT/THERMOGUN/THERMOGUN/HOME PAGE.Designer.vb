﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class WELCOME_TO_DTTRS
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(WELCOME_TO_DTTRS))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PanelDesktop = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PanelTile = New System.Windows.Forms.Panel()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.ButtonX = New System.Windows.Forms.Button()
        Me.LblFormTile = New System.Windows.Forms.Label()
        Me.IconcurrentHome = New FontAwesome.Sharp.IconPictureBox()
        Me.Panelmenu = New System.Windows.Forms.Panel()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.btnsetting = New FontAwesome.Sharp.IconButton()
        Me.BtnView = New FontAwesome.Sharp.IconButton()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.BtnPrint = New FontAwesome.Sharp.IconButton()
        Me.BtnhomePage = New FontAwesome.Sharp.IconButton()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.BtnLogIn = New FontAwesome.Sharp.IconButton()
        Me.btnDASHBOAD = New FontAwesome.Sharp.IconButton()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.IconButton1 = New FontAwesome.Sharp.IconButton()
        Me.Panellogo = New System.Windows.Forms.Panel()
        Me.imageHome = New System.Windows.Forms.PictureBox()
        Me.FontDialog1 = New System.Windows.Forms.FontDialog()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel1.SuspendLayout()
        Me.PanelDesktop.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelTile.SuspendLayout()
        CType(Me.IconcurrentHome, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panelmenu.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panellogo.SuspendLayout()
        CType(Me.imageHome, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel1.Controls.Add(Me.PanelDesktop)
        Me.Panel1.Controls.Add(Me.PanelTile)
        Me.Panel1.Controls.Add(Me.Panelmenu)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1087, 749)
        Me.Panel1.TabIndex = 0
        '
        'PanelDesktop
        '
        Me.PanelDesktop.BackColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(33, Byte), Integer), CType(CType(74, Byte), Integer))
        Me.PanelDesktop.Controls.Add(Me.PictureBox1)
        Me.PanelDesktop.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelDesktop.Location = New System.Drawing.Point(215, 75)
        Me.PanelDesktop.Name = "PanelDesktop"
        Me.PanelDesktop.Size = New System.Drawing.Size(872, 674)
        Me.PanelDesktop.TabIndex = 5
        '
        'PictureBox1
        '
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(872, 674)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 5
        Me.PictureBox1.TabStop = False
        '
        'PanelTile
        '
        Me.PanelTile.BackColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(62, Byte), Integer))
        Me.PanelTile.Controls.Add(Me.TextBox1)
        Me.PanelTile.Controls.Add(Me.ButtonX)
        Me.PanelTile.Controls.Add(Me.LblFormTile)
        Me.PanelTile.Controls.Add(Me.IconcurrentHome)
        Me.PanelTile.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelTile.Location = New System.Drawing.Point(215, 0)
        Me.PanelTile.Name = "PanelTile"
        Me.PanelTile.Size = New System.Drawing.Size(872, 75)
        Me.PanelTile.TabIndex = 4
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.ForeColor = System.Drawing.SystemColors.Window
        Me.TextBox1.Location = New System.Drawing.Point(178, 3)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(457, 26)
        Me.TextBox1.TabIndex = 3
        Me.TextBox1.Text = "WELCOME TO THE DTTRS!!!"
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ButtonX
        '
        Me.ButtonX.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ButtonX.Location = New System.Drawing.Point(789, 0)
        Me.ButtonX.Name = "ButtonX"
        Me.ButtonX.Size = New System.Drawing.Size(83, 32)
        Me.ButtonX.TabIndex = 2
        Me.ButtonX.Text = "SHUT-DOWN"
        Me.ButtonX.UseVisualStyleBackColor = True
        '
        'LblFormTile
        '
        Me.LblFormTile.AutoSize = True
        Me.LblFormTile.ForeColor = System.Drawing.Color.Gainsboro
        Me.LblFormTile.Location = New System.Drawing.Point(44, 31)
        Me.LblFormTile.Name = "LblFormTile"
        Me.LblFormTile.Size = New System.Drawing.Size(35, 13)
        Me.LblFormTile.TabIndex = 1
        Me.LblFormTile.Text = "Home"
        '
        'IconcurrentHome
        '
        Me.IconcurrentHome.BackColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(62, Byte), Integer))
        Me.IconcurrentHome.ForeColor = System.Drawing.Color.MediumPurple
        Me.IconcurrentHome.IconChar = FontAwesome.Sharp.IconChar.Home
        Me.IconcurrentHome.IconColor = System.Drawing.Color.MediumPurple
        Me.IconcurrentHome.Location = New System.Drawing.Point(6, 22)
        Me.IconcurrentHome.Name = "IconcurrentHome"
        Me.IconcurrentHome.Size = New System.Drawing.Size(32, 32)
        Me.IconcurrentHome.TabIndex = 0
        Me.IconcurrentHome.TabStop = False
        '
        'Panelmenu
        '
        Me.Panelmenu.BackColor = System.Drawing.Color.FromArgb(CType(CType(31, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(68, Byte), Integer))
        Me.Panelmenu.Controls.Add(Me.Panel5)
        Me.Panelmenu.Controls.Add(Me.BtnView)
        Me.Panelmenu.Controls.Add(Me.Panel4)
        Me.Panelmenu.Controls.Add(Me.BtnhomePage)
        Me.Panelmenu.Controls.Add(Me.Panel3)
        Me.Panelmenu.Controls.Add(Me.btnDASHBOAD)
        Me.Panelmenu.Controls.Add(Me.Panel2)
        Me.Panelmenu.Controls.Add(Me.Panellogo)
        Me.Panelmenu.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panelmenu.Location = New System.Drawing.Point(0, 0)
        Me.Panelmenu.Name = "Panelmenu"
        Me.Panelmenu.Size = New System.Drawing.Size(215, 749)
        Me.Panelmenu.TabIndex = 3
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.btnsetting)
        Me.Panel5.Location = New System.Drawing.Point(0, 348)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(214, 54)
        Me.Panel5.TabIndex = 10
        '
        'btnsetting
        '
        Me.btnsetting.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnsetting.FlatAppearance.BorderSize = 0
        Me.btnsetting.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnsetting.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.btnsetting.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.btnsetting.IconChar = FontAwesome.Sharp.IconChar.UserCog
        Me.btnsetting.IconColor = System.Drawing.Color.Gainsboro
        Me.btnsetting.IconSize = 32
        Me.btnsetting.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnsetting.Location = New System.Drawing.Point(0, 0)
        Me.btnsetting.MinimumSize = New System.Drawing.Size(210, 50)
        Me.btnsetting.Name = "btnsetting"
        Me.btnsetting.Padding = New System.Windows.Forms.Padding(10, 0, 20, 0)
        Me.btnsetting.Rotation = 0R
        Me.btnsetting.Size = New System.Drawing.Size(214, 50)
        Me.btnsetting.TabIndex = 1
        Me.btnsetting.Text = "Setting"
        Me.btnsetting.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnsetting.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnsetting.UseVisualStyleBackColor = True
        '
        'BtnView
        '
        Me.BtnView.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnView.FlatAppearance.BorderSize = 0
        Me.BtnView.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnView.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.BtnView.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.BtnView.IconChar = FontAwesome.Sharp.IconChar.Binoculars
        Me.BtnView.IconColor = System.Drawing.Color.Gainsboro
        Me.BtnView.IconSize = 32
        Me.BtnView.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnView.Location = New System.Drawing.Point(0, 190)
        Me.BtnView.MinimumSize = New System.Drawing.Size(210, 50)
        Me.BtnView.Name = "BtnView"
        Me.BtnView.Padding = New System.Windows.Forms.Padding(10, 0, 20, 0)
        Me.BtnView.Rotation = 0R
        Me.BtnView.Size = New System.Drawing.Size(215, 50)
        Me.BtnView.TabIndex = 9
        Me.BtnView.Text = "View"
        Me.BtnView.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnView.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnView.UseVisualStyleBackColor = True
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.BtnPrint)
        Me.Panel4.Location = New System.Drawing.Point(3, 292)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(214, 54)
        Me.Panel4.TabIndex = 8
        '
        'BtnPrint
        '
        Me.BtnPrint.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnPrint.FlatAppearance.BorderSize = 0
        Me.BtnPrint.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnPrint.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.BtnPrint.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.BtnPrint.IconChar = FontAwesome.Sharp.IconChar.Print
        Me.BtnPrint.IconColor = System.Drawing.Color.Gainsboro
        Me.BtnPrint.IconSize = 32
        Me.BtnPrint.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnPrint.Location = New System.Drawing.Point(0, 0)
        Me.BtnPrint.MinimumSize = New System.Drawing.Size(210, 50)
        Me.BtnPrint.Name = "BtnPrint"
        Me.BtnPrint.Padding = New System.Windows.Forms.Padding(10, 0, 20, 0)
        Me.BtnPrint.Rotation = 0R
        Me.BtnPrint.Size = New System.Drawing.Size(214, 50)
        Me.BtnPrint.TabIndex = 1
        Me.BtnPrint.Text = "Print Report"
        Me.BtnPrint.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnPrint.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnPrint.UseVisualStyleBackColor = True
        '
        'BtnhomePage
        '
        Me.BtnhomePage.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnhomePage.FlatAppearance.BorderSize = 0
        Me.BtnhomePage.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnhomePage.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.BtnhomePage.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.BtnhomePage.IconChar = FontAwesome.Sharp.IconChar.HouseDamage
        Me.BtnhomePage.IconColor = System.Drawing.Color.Gainsboro
        Me.BtnhomePage.IconSize = 32
        Me.BtnhomePage.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnhomePage.Location = New System.Drawing.Point(0, 140)
        Me.BtnhomePage.MinimumSize = New System.Drawing.Size(210, 50)
        Me.BtnhomePage.Name = "BtnhomePage"
        Me.BtnhomePage.Padding = New System.Windows.Forms.Padding(10, 0, 20, 0)
        Me.BtnhomePage.Rotation = 0R
        Me.BtnhomePage.Size = New System.Drawing.Size(215, 50)
        Me.BtnhomePage.TabIndex = 7
        Me.BtnhomePage.Text = "Home Page"
        Me.BtnhomePage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnhomePage.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnhomePage.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.BtnLogIn)
        Me.Panel3.Location = New System.Drawing.Point(0, 236)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(214, 46)
        Me.Panel3.TabIndex = 6
        '
        'BtnLogIn
        '
        Me.BtnLogIn.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnLogIn.FlatAppearance.BorderSize = 0
        Me.BtnLogIn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnLogIn.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.BtnLogIn.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.BtnLogIn.IconChar = FontAwesome.Sharp.IconChar.Sign
        Me.BtnLogIn.IconColor = System.Drawing.Color.Gainsboro
        Me.BtnLogIn.IconSize = 32
        Me.BtnLogIn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnLogIn.Location = New System.Drawing.Point(0, 0)
        Me.BtnLogIn.MinimumSize = New System.Drawing.Size(210, 50)
        Me.BtnLogIn.Name = "BtnLogIn"
        Me.BtnLogIn.Padding = New System.Windows.Forms.Padding(10, 0, 20, 0)
        Me.BtnLogIn.Rotation = 0R
        Me.BtnLogIn.Size = New System.Drawing.Size(214, 50)
        Me.BtnLogIn.TabIndex = 1
        Me.BtnLogIn.Text = "Log-In"
        Me.BtnLogIn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnLogIn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnLogIn.UseVisualStyleBackColor = True
        '
        'btnDASHBOAD
        '
        Me.btnDASHBOAD.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnDASHBOAD.FlatAppearance.BorderSize = 0
        Me.btnDASHBOAD.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDASHBOAD.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.btnDASHBOAD.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.btnDASHBOAD.IconChar = FontAwesome.Sharp.IconChar.ChartLine
        Me.btnDASHBOAD.IconColor = System.Drawing.Color.Gainsboro
        Me.btnDASHBOAD.IconSize = 32
        Me.btnDASHBOAD.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnDASHBOAD.Location = New System.Drawing.Point(0, 90)
        Me.btnDASHBOAD.MinimumSize = New System.Drawing.Size(210, 50)
        Me.btnDASHBOAD.Name = "btnDASHBOAD"
        Me.btnDASHBOAD.Padding = New System.Windows.Forms.Padding(10, 0, 20, 0)
        Me.btnDASHBOAD.Rotation = 0R
        Me.btnDASHBOAD.Size = New System.Drawing.Size(215, 50)
        Me.btnDASHBOAD.TabIndex = 5
        Me.btnDASHBOAD.Text = "DASHBOARD"
        Me.btnDASHBOAD.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnDASHBOAD.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnDASHBOAD.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.IconButton1)
        Me.Panel2.Location = New System.Drawing.Point(3, 96)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(214, 54)
        Me.Panel2.TabIndex = 4
        '
        'IconButton1
        '
        Me.IconButton1.Dock = System.Windows.Forms.DockStyle.Top
        Me.IconButton1.FlatAppearance.BorderSize = 0
        Me.IconButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton1.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton1.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.IconButton1.IconChar = FontAwesome.Sharp.IconChar.Hospital
        Me.IconButton1.IconColor = System.Drawing.Color.Gainsboro
        Me.IconButton1.IconSize = 32
        Me.IconButton1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.IconButton1.Location = New System.Drawing.Point(0, 0)
        Me.IconButton1.MinimumSize = New System.Drawing.Size(210, 50)
        Me.IconButton1.Name = "IconButton1"
        Me.IconButton1.Padding = New System.Windows.Forms.Padding(10, 0, 20, 0)
        Me.IconButton1.Rotation = 0R
        Me.IconButton1.Size = New System.Drawing.Size(214, 50)
        Me.IconButton1.TabIndex = 1
        Me.IconButton1.Text = "IconButton1"
        Me.IconButton1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.IconButton1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.IconButton1.UseVisualStyleBackColor = True
        '
        'Panellogo
        '
        Me.Panellogo.Controls.Add(Me.imageHome)
        Me.Panellogo.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panellogo.Location = New System.Drawing.Point(0, 0)
        Me.Panellogo.Name = "Panellogo"
        Me.Panellogo.Size = New System.Drawing.Size(215, 90)
        Me.Panellogo.TabIndex = 4
        '
        'imageHome
        '
        Me.imageHome.Image = CType(resources.GetObject("imageHome.Image"), System.Drawing.Image)
        Me.imageHome.Location = New System.Drawing.Point(36, 12)
        Me.imageHome.Name = "imageHome"
        Me.imageHome.Size = New System.Drawing.Size(126, 65)
        Me.imageHome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.imageHome.TabIndex = 4
        Me.imageHome.TabStop = False
        '
        'Timer1
        '
        '
        'WELCOME_TO_DTTRS
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1087, 749)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "WELCOME_TO_DTTRS"
        Me.Text = "WELCOME_TO_DTTRS"
        Me.Panel1.ResumeLayout(False)
        Me.PanelDesktop.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelTile.ResumeLayout(False)
        Me.PanelTile.PerformLayout()
        CType(Me.IconcurrentHome, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panelmenu.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panellogo.ResumeLayout(False)
        CType(Me.imageHome, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents FontDialog1 As FontDialog
    Friend WithEvents Panelmenu As Panel
    Friend WithEvents PanelDesktop As Panel
    Friend WithEvents PanelTile As Panel
    Friend WithEvents ButtonX As Button
    Friend WithEvents LblFormTile As Label
    Friend WithEvents IconcurrentHome As FontAwesome.Sharp.IconPictureBox
    Friend WithEvents Panel5 As Panel
    Friend WithEvents btnsetting As FontAwesome.Sharp.IconButton
    Friend WithEvents BtnView As FontAwesome.Sharp.IconButton
    Friend WithEvents Panel4 As Panel
    Friend WithEvents BtnPrint As FontAwesome.Sharp.IconButton
    Friend WithEvents BtnhomePage As FontAwesome.Sharp.IconButton
    Friend WithEvents Panel3 As Panel
    Friend WithEvents BtnLogIn As FontAwesome.Sharp.IconButton
    Friend WithEvents btnDASHBOAD As FontAwesome.Sharp.IconButton
    Friend WithEvents Panel2 As Panel
    Friend WithEvents IconButton1 As FontAwesome.Sharp.IconButton
    Friend WithEvents Panellogo As Panel
    Friend WithEvents imageHome As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Timer1 As Timer
End Class
