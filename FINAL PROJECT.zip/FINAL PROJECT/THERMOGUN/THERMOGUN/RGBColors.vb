﻿Public Structure RGBColors
    Public Shared color1 As Color = Color.FromArgb(172, 126, 2)
    Public Shared color2 As Color = Color.FromArgb(240, 118, 176)
    Public Shared color3 As Color = Color.FromArgb(253, 138, 114)
    Public Shared color4 As Color = Color.FromArgb(95, 77, 221)
    Public Shared color5 As Color = Color.FromArgb(249, 88, 155)
    Public Shared color6 As Color = Color.FromArgb(24, 161, 251)
End Structure
