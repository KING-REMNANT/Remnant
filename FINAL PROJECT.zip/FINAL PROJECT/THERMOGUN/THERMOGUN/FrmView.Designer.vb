﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmDIAGNOSIS
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmDIAGNOSIS))
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Button1SEND = New System.Windows.Forms.Button()
        Me.CheckBoxfever = New System.Windows.Forms.CheckBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.PictureBox1rushes = New System.Windows.Forms.PictureBox()
        Me.TextBoxfever = New System.Windows.Forms.TextBox()
        Me.PictureBox1fatigue = New System.Windows.Forms.PictureBox()
        Me.PictureBox1AcheandPain = New System.Windows.Forms.PictureBox()
        Me.PictureBox1CONJUNCTIVITIS = New System.Windows.Forms.PictureBox()
        Me.CheckBox4 = New System.Windows.Forms.CheckBox()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.CheckBoxconjunctivitis = New System.Windows.Forms.CheckBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.CheckBox11 = New System.Windows.Forms.CheckBox()
        Me.CheckBox10 = New System.Windows.Forms.CheckBox()
        Me.CheckBox9 = New System.Windows.Forms.CheckBox()
        Me.CheckBox8 = New System.Windows.Forms.CheckBox()
        Me.CheckBox6 = New System.Windows.Forms.CheckBox()
        Me.CheckBoxaches = New System.Windows.Forms.CheckBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.CheckBox12 = New System.Windows.Forms.CheckBox()
        Me.CheckBox13 = New System.Windows.Forms.CheckBox()
        Me.CheckBox15 = New System.Windows.Forms.CheckBox()
        Me.CheckBoxFatigue = New System.Windows.Forms.CheckBox()
        Me.CheckBox17 = New System.Windows.Forms.CheckBox()
        Me.CheckBox18 = New System.Windows.Forms.CheckBox()
        Me.CheckBox19 = New System.Windows.Forms.CheckBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox1rushes, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1fatigue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1AcheandPain, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1CONJUNCTIVITIS, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.Color.OliveDrab
        Me.TextBox2.Location = New System.Drawing.Point(12, 191)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(342, 17)
        Me.TextBox2.TabIndex = 3
        '
        'Button1SEND
        '
        Me.Button1SEND.Location = New System.Drawing.Point(658, 408)
        Me.Button1SEND.Name = "Button1SEND"
        Me.Button1SEND.Size = New System.Drawing.Size(75, 23)
        Me.Button1SEND.TabIndex = 4
        Me.Button1SEND.Text = "SEND"
        Me.Button1SEND.UseVisualStyleBackColor = True
        '
        'CheckBoxfever
        '
        Me.CheckBoxfever.AutoSize = True
        Me.CheckBoxfever.Location = New System.Drawing.Point(6, 19)
        Me.CheckBoxfever.Name = "CheckBoxfever"
        Me.CheckBoxfever.Size = New System.Drawing.Size(73, 24)
        Me.CheckBoxfever.TabIndex = 9
        Me.CheckBoxfever.Text = "Fever"
        Me.CheckBoxfever.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Black
        Me.GroupBox1.Controls.Add(Me.PictureBox1rushes)
        Me.GroupBox1.Controls.Add(Me.TextBoxfever)
        Me.GroupBox1.Controls.Add(Me.PictureBox1fatigue)
        Me.GroupBox1.Controls.Add(Me.PictureBox1AcheandPain)
        Me.GroupBox1.Controls.Add(Me.PictureBox1CONJUNCTIVITIS)
        Me.GroupBox1.Controls.Add(Me.CheckBox4)
        Me.GroupBox1.Controls.Add(Me.CheckBox2)
        Me.GroupBox1.Controls.Add(Me.CheckBoxfever)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.GroupBox1.Location = New System.Drawing.Point(18, 214)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(336, 224)
        Me.GroupBox1.TabIndex = 10
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "COMMON SYMPTOMS"
        '
        'PictureBox1rushes
        '
        Me.PictureBox1rushes.Image = CType(resources.GetObject("PictureBox1rushes.Image"), System.Drawing.Image)
        Me.PictureBox1rushes.Location = New System.Drawing.Point(132, 17)
        Me.PictureBox1rushes.Name = "PictureBox1rushes"
        Me.PictureBox1rushes.Size = New System.Drawing.Size(180, 154)
        Me.PictureBox1rushes.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1rushes.TabIndex = 17
        Me.PictureBox1rushes.TabStop = False
        '
        'TextBoxfever
        '
        Me.TextBoxfever.Location = New System.Drawing.Point(111, 17)
        Me.TextBoxfever.Multiline = True
        Me.TextBoxfever.Name = "TextBoxfever"
        Me.TextBoxfever.Size = New System.Drawing.Size(219, 154)
        Me.TextBoxfever.TabIndex = 16
        Me.TextBoxfever.Text = "A fever is a temporary increase in your body temperature, often due to an illness" &
    ". Having a fever is a sign that something out of the ordinary is going on in you" &
    "r body"
        '
        'PictureBox1fatigue
        '
        Me.PictureBox1fatigue.Image = CType(resources.GetObject("PictureBox1fatigue.Image"), System.Drawing.Image)
        Me.PictureBox1fatigue.Location = New System.Drawing.Point(166, 25)
        Me.PictureBox1fatigue.Name = "PictureBox1fatigue"
        Me.PictureBox1fatigue.Size = New System.Drawing.Size(100, 90)
        Me.PictureBox1fatigue.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1fatigue.TabIndex = 15
        Me.PictureBox1fatigue.TabStop = False
        '
        'PictureBox1AcheandPain
        '
        Me.PictureBox1AcheandPain.Image = CType(resources.GetObject("PictureBox1AcheandPain.Image"), System.Drawing.Image)
        Me.PictureBox1AcheandPain.Location = New System.Drawing.Point(132, 25)
        Me.PictureBox1AcheandPain.Name = "PictureBox1AcheandPain"
        Me.PictureBox1AcheandPain.Size = New System.Drawing.Size(100, 90)
        Me.PictureBox1AcheandPain.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1AcheandPain.TabIndex = 14
        Me.PictureBox1AcheandPain.TabStop = False
        '
        'PictureBox1CONJUNCTIVITIS
        '
        Me.PictureBox1CONJUNCTIVITIS.Image = CType(resources.GetObject("PictureBox1CONJUNCTIVITIS.Image"), System.Drawing.Image)
        Me.PictureBox1CONJUNCTIVITIS.Location = New System.Drawing.Point(118, 25)
        Me.PictureBox1CONJUNCTIVITIS.Name = "PictureBox1CONJUNCTIVITIS"
        Me.PictureBox1CONJUNCTIVITIS.Size = New System.Drawing.Size(105, 90)
        Me.PictureBox1CONJUNCTIVITIS.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1CONJUNCTIVITIS.TabIndex = 13
        Me.PictureBox1CONJUNCTIVITIS.TabStop = False
        '
        'CheckBox4
        '
        Me.CheckBox4.AutoSize = True
        Me.CheckBox4.Location = New System.Drawing.Point(6, 130)
        Me.CheckBox4.Name = "CheckBox4"
        Me.CheckBox4.Size = New System.Drawing.Size(106, 24)
        Me.CheckBox4.TabIndex = 12
        Me.CheckBox4.Text = "Tiredness"
        Me.CheckBox4.UseVisualStyleBackColor = True
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Location = New System.Drawing.Point(3, 67)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(109, 24)
        Me.CheckBox2.TabIndex = 10
        Me.CheckBox2.Text = "Dry cough"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'CheckBoxconjunctivitis
        '
        Me.CheckBoxconjunctivitis.AutoSize = True
        Me.CheckBoxconjunctivitis.Location = New System.Drawing.Point(211, 19)
        Me.CheckBoxconjunctivitis.Name = "CheckBoxconjunctivitis"
        Me.CheckBoxconjunctivitis.Size = New System.Drawing.Size(131, 24)
        Me.CheckBoxconjunctivitis.TabIndex = 11
        Me.CheckBoxconjunctivitis.Text = "conjunctivitis"
        Me.CheckBoxconjunctivitis.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Black
        Me.GroupBox2.Controls.Add(Me.CheckBox11)
        Me.GroupBox2.Controls.Add(Me.CheckBox10)
        Me.GroupBox2.Controls.Add(Me.CheckBox9)
        Me.GroupBox2.Controls.Add(Me.CheckBox8)
        Me.GroupBox2.Controls.Add(Me.CheckBox6)
        Me.GroupBox2.Controls.Add(Me.CheckBoxconjunctivitis)
        Me.GroupBox2.Controls.Add(Me.CheckBoxaches)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.GroupBox2.Location = New System.Drawing.Point(12, 13)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(342, 171)
        Me.GroupBox2.TabIndex = 13
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "LESS COMMON SYMPTOMS"
        '
        'CheckBox11
        '
        Me.CheckBox11.AutoSize = True
        Me.CheckBox11.Location = New System.Drawing.Point(6, 148)
        Me.CheckBox11.Name = "CheckBox11"
        Me.CheckBox11.Size = New System.Drawing.Size(295, 24)
        Me.CheckBox11.TabIndex = 16
        Me.CheckBox11.Text = "Discolouration of fingures or toes"
        Me.CheckBox11.UseVisualStyleBackColor = True
        '
        'CheckBox10
        '
        Me.CheckBox10.AutoSize = True
        Me.CheckBox10.Location = New System.Drawing.Point(211, 98)
        Me.CheckBox10.Name = "CheckBox10"
        Me.CheckBox10.Size = New System.Drawing.Size(107, 24)
        Me.CheckBox10.TabIndex = 15
        Me.CheckBox10.Text = "headache"
        Me.CheckBox10.UseVisualStyleBackColor = True
        '
        'CheckBox9
        '
        Me.CheckBox9.AutoSize = True
        Me.CheckBox9.Location = New System.Drawing.Point(6, 98)
        Me.CheckBox9.Name = "CheckBox9"
        Me.CheckBox9.Size = New System.Drawing.Size(132, 24)
        Me.CheckBox9.TabIndex = 14
        Me.CheckBox9.Text = "Rash on skin"
        Me.CheckBox9.UseVisualStyleBackColor = True
        '
        'CheckBox8
        '
        Me.CheckBox8.AutoSize = True
        Me.CheckBox8.Location = New System.Drawing.Point(6, 49)
        Me.CheckBox8.Name = "CheckBox8"
        Me.CheckBox8.Size = New System.Drawing.Size(191, 24)
        Me.CheckBox8.TabIndex = 13
        Me.CheckBox8.Text = "lost of taste or smell"
        Me.CheckBox8.UseVisualStyleBackColor = True
        '
        'CheckBox6
        '
        Me.CheckBox6.AutoSize = True
        Me.CheckBox6.Location = New System.Drawing.Point(211, 59)
        Me.CheckBox6.Name = "CheckBox6"
        Me.CheckBox6.Size = New System.Drawing.Size(119, 24)
        Me.CheckBox6.TabIndex = 10
        Me.CheckBox6.Text = "Sore throat"
        Me.CheckBox6.UseVisualStyleBackColor = True
        '
        'CheckBoxaches
        '
        Me.CheckBoxaches.AutoSize = True
        Me.CheckBoxaches.Location = New System.Drawing.Point(6, 19)
        Me.CheckBoxaches.Name = "CheckBoxaches"
        Me.CheckBoxaches.Size = New System.Drawing.Size(161, 24)
        Me.CheckBoxaches.TabIndex = 9
        Me.CheckBoxaches.Text = "Aches and pains"
        Me.CheckBoxaches.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.Black
        Me.GroupBox3.Controls.Add(Me.CheckBox12)
        Me.GroupBox3.Controls.Add(Me.CheckBox13)
        Me.GroupBox3.Controls.Add(Me.CheckBox15)
        Me.GroupBox3.Controls.Add(Me.CheckBoxFatigue)
        Me.GroupBox3.Controls.Add(Me.CheckBox17)
        Me.GroupBox3.Controls.Add(Me.CheckBox18)
        Me.GroupBox3.Controls.Add(Me.CheckBox19)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.GroupBox3.Location = New System.Drawing.Point(391, 13)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(397, 425)
        Me.GroupBox3.TabIndex = 17
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "SERIOUS SYMPTOMS"
        '
        'CheckBox12
        '
        Me.CheckBox12.AutoSize = True
        Me.CheckBox12.Location = New System.Drawing.Point(216, 331)
        Me.CheckBox12.Name = "CheckBox12"
        Me.CheckBox12.Size = New System.Drawing.Size(181, 24)
        Me.CheckBox12.TabIndex = 16
        Me.CheckBox12.Text = "Nausea or vomiting"
        Me.CheckBox12.UseVisualStyleBackColor = True
        '
        'CheckBox13
        '
        Me.CheckBox13.AutoSize = True
        Me.CheckBox13.Location = New System.Drawing.Point(6, 331)
        Me.CheckBox13.Name = "CheckBox13"
        Me.CheckBox13.Size = New System.Drawing.Size(192, 24)
        Me.CheckBox13.TabIndex = 15
        Me.CheckBox13.Text = "Muscle or body ache"
        Me.CheckBox13.UseVisualStyleBackColor = True
        '
        'CheckBox15
        '
        Me.CheckBox15.AutoSize = True
        Me.CheckBox15.Location = New System.Drawing.Point(6, 48)
        Me.CheckBox15.Name = "CheckBox15"
        Me.CheckBox15.Size = New System.Drawing.Size(119, 24)
        Me.CheckBox15.TabIndex = 13
        Me.CheckBox15.Text = "Sore throat"
        Me.CheckBox15.UseVisualStyleBackColor = True
        '
        'CheckBoxFatigue
        '
        Me.CheckBoxFatigue.AutoSize = True
        Me.CheckBoxFatigue.Location = New System.Drawing.Point(267, 48)
        Me.CheckBoxFatigue.Name = "CheckBoxFatigue"
        Me.CheckBoxFatigue.Size = New System.Drawing.Size(89, 24)
        Me.CheckBoxFatigue.TabIndex = 12
        Me.CheckBoxFatigue.Text = "Fatigue"
        Me.CheckBoxFatigue.UseVisualStyleBackColor = True
        '
        'CheckBox17
        '
        Me.CheckBox17.AutoSize = True
        Me.CheckBox17.Location = New System.Drawing.Point(6, 171)
        Me.CheckBox17.Name = "CheckBox17"
        Me.CheckBox17.Size = New System.Drawing.Size(258, 24)
        Me.CheckBox17.TabIndex = 10
        Me.CheckBox17.Text = "Less of speach or movement"
        Me.CheckBox17.UseVisualStyleBackColor = True
        '
        'CheckBox18
        '
        Me.CheckBox18.AutoSize = True
        Me.CheckBox18.Location = New System.Drawing.Point(6, 248)
        Me.CheckBox18.Name = "CheckBox18"
        Me.CheckBox18.Size = New System.Drawing.Size(210, 24)
        Me.CheckBox18.TabIndex = 11
        Me.CheckBox18.Text = "Chest pain or pressure"
        Me.CheckBox18.UseVisualStyleBackColor = True
        '
        'CheckBox19
        '
        Me.CheckBox19.AutoSize = True
        Me.CheckBox19.Location = New System.Drawing.Point(6, 113)
        Me.CheckBox19.Name = "CheckBox19"
        Me.CheckBox19.Size = New System.Drawing.Size(179, 24)
        Me.CheckBox19.TabIndex = 9
        Me.CheckBox19.Text = "Difficulty breathing"
        Me.CheckBox19.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.Maroon
        Me.TextBox1.Location = New System.Drawing.Point(353, 13)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(38, 425)
        Me.TextBox1.TabIndex = 18
        '
        'FrmDIAGNOSIS
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(110, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Button1SEND)
        Me.Controls.Add(Me.TextBox2)
        Me.Name = "FrmDIAGNOSIS"
        Me.Text = "SPECIALIST DIAGNOSIS"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PictureBox1rushes, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1fatigue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1AcheandPain, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1CONJUNCTIVITIS, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Button1SEND As Button
    Friend WithEvents CheckBoxfever As CheckBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents CheckBox4 As CheckBox
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents CheckBoxconjunctivitis As CheckBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents CheckBox11 As CheckBox
    Friend WithEvents CheckBox10 As CheckBox
    Friend WithEvents CheckBox9 As CheckBox
    Friend WithEvents CheckBox8 As CheckBox
    Friend WithEvents CheckBox6 As CheckBox
    Friend WithEvents CheckBoxaches As CheckBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents CheckBox12 As CheckBox
    Friend WithEvents CheckBox13 As CheckBox
    Friend WithEvents CheckBox15 As CheckBox
    Friend WithEvents CheckBoxFatigue As CheckBox
    Friend WithEvents CheckBox17 As CheckBox
    Friend WithEvents CheckBox18 As CheckBox
    Friend WithEvents CheckBox19 As CheckBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents PictureBox1fatigue As PictureBox
    Friend WithEvents PictureBox1AcheandPain As PictureBox
    Friend WithEvents PictureBox1CONJUNCTIVITIS As PictureBox
    Friend WithEvents TextBoxfever As TextBox
    Friend WithEvents PictureBox1rushes As PictureBox
End Class
