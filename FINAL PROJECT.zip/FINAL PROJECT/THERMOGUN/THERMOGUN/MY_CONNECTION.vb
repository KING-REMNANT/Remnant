﻿Imports MySql.Data.MySqlClient
Public Class MY_CONNECTION
    Private CONNECTION As New MySqlConnection("datasource=localhost;port=3306;  username=root; pwd=Remnant-123; Database=logindatabase")
    ReadOnly Property getConnection() As MySqlConnection
        Get
            Return CONNECTION
        End Get
    End Property
    Dim query As String = "select* from user"
    ' open the connection
    Sub openConnection()

        If CONNECTION.State = ConnectionState.Closed Then
            CONNECTION.Open()
        End If
    End Sub
    ' close the connection
    Sub closeConnection()
        If CONNECTION.State = ConnectionState.Open Then
            CONNECTION.Close()
        End If

    End Sub
End Class
