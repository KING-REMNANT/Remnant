﻿Imports MySql.Data.MySqlClient

Public Class FrmHomepage
    Dim counter As Integer
    Dim str As String = "server=localhost; user=root; pwd=Remnant-123; Database=thermogun1"
    Dim con As New MySqlConnection(str)
    Dim mySQLCMD As MySqlCommand
    Dim mySQLDA As MySqlDataAdapter
    Dim DT As New DataTable
    Dim tablethermo1 As String = "tablethermo1"
    Dim data As String
    Dim sqlCMDsearchstr As String
    Public Sub Load()
        Try
            Dim query As String = "select* from tablethermo1"
            ' Dim query As String = "select* from Details"
            Dim adpt As New MySqlDataAdapter(query, con)
            Dim ds As New DataSet
            ' adpt.Fill(ds, "emp")
            ' DataGridView1.DataSource = ds.Tables(0)
            ' con.Close()
            ' DataGridView1.Visible = 0

            ' Dim adpt As New MySqlDataAdapter(query, con)
            ' Dim ds As New DataSet
            adpt.Fill(ds, "Emp")
            DataGridView1.DataSource = ds.Tables(0)
            con.Close()
            ID_NUMBERTextBox.Text = ""
            PHONE_NOTextBox.Text = ""
            FIRST_NAMETextBox.Text = ""
            SURNAMETextBox.Text = ""
            GENDERcomboBox.Text = ""
            AGETextBox.Text = ""
            COUNTYcomboBox.Text = ""
            TEMPERATURETextBox.Text = ""
        Catch ex As Exception
            MessageBox.Show("PLEASE CHECK YOUR  SERVER CONNECTION !!!", "error message", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End Try
    End Sub
    Private Sub FrmHomepage_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DataGridView1.Visible = 0
        counter = 0
        Load()
    End Sub
    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick

        Dim ROW As DataGridViewRow = DataGridView1.CurrentRow
        Try
            ID_NUMBERTextBox.Text = ROW.Cells(0).Value.ToString()
            PHONE_NOTextBox.Text = ROW.Cells(1).Value.ToString()
            FIRST_NAMETextBox.Text = ROW.Cells(2).Value.ToString()
            SURNAMETextBox.Text = ROW.Cells(3).Value.ToString()
            AGETextBox.Text = ROW.Cells(4).Value.ToString()
            GENDERcomboBox.Text = ROW.Cells(5).Value.ToString()
            COUNTYcomboBox.Text = ROW.Cells(6).Value.ToString()
            TEMPERATURETextBox.Text = ROW.Cells(7).Value.ToString()
        Catch ex As Exception
            MessageBox.Show("THERE ARE NO DATA FOUND!!!", "error message", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End Try
    End Sub
    Private Sub ButtonSave_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click



        Try
            If ID_NUMBERTextBox.Text = "" Then
                MessageBox.Show("ID Number cannot be empty!!!", "error message", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return
            End If
            If PHONE_NOTextBox.Text = "" Then
                MessageBox.Show("Phnoe number cannot be empty!!!", "error message", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return
            End If
            If FIRST_NAMETextBox.Text = "" Then
                MessageBox.Show("First Name cannot be empty!!!", "error message", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return
            End If

            If SURNAMETextBox.Text = "" Then
                MessageBox.Show("Sur-Name cannot be empty!!!", "error message", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return
            End If
            If COUNTYcomboBox.Text = "" Then
                MessageBox.Show("county cannot be empty!!!", "error message", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return
            End If
            If TEMPERATURETextBox.Text = "" Then
                MessageBox.Show("Temperature Name cannot be empty!!!", "error message", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return
            End If
            If AGETextBox.Text = "" Then
                MessageBox.Show("Age cannot be empty!!!", "error message", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return
            End If
            If GENDERcomboBox.Text = "" Then
                MessageBox.Show("Gender cannot be empty!!!", "error message", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return
            End If
            Dim cmd As MySqlCommand
            con.Open()

            cmd = con.CreateCommand
            cmd.CommandText = "INSERT INTO tablethermo1(ID_NUMBER, PHONE_NO,AGE,TEMPERATURE,COUNTY,FIRST_NAME, SURNAME,GENDER) VALUES (@ID_NUMBER, @PHONE_NO,@AGE,@TEMPERATURE,@COUNTY,@FIRST_NAME, @SURNAME,@GENDER);"
            cmd.Parameters.AddWithValue("@ID_NUMBER", ID_NUMBERTextBox.Text)
            cmd.Parameters.AddWithValue("@PHONE_NO", PHONE_NOTextBox.Text)
            cmd.Parameters.AddWithValue("@AGE", AGETextBox.Text)
            cmd.Parameters.AddWithValue("@TEMPERATURE", TEMPERATURETextBox.Text)
            cmd.Parameters.AddWithValue("@COUNTY", COUNTYcomboBox.Text)
            cmd.Parameters.AddWithValue("@FIRST_NAME", FIRST_NAMETextBox.Text)
            cmd.Parameters.AddWithValue("@SURNAME", SURNAMETextBox.Text)
            cmd.Parameters.AddWithValue("@GENDER", GENDERcomboBox.Text)
            cmd.ExecuteNonQuery()
            Load()
            If TEMPERATURETextBox.Text >= 36.1 + TEMPERATURETextBox.Text <= 37.2 Then
                counter = counter + 1
                Buttonnormal.Text = counter
            ElseIf TEMPERATURETextBox.Text >= 34.0 + TEMPERATURETextBox.Text <= 36.0 Then
                counter = counter + 1
                ButtonMedium.Text = counter
            Else
                counter = counter + 1
                Buttonhigh.Text = counter
            End If
        Catch ex As Exception
            MessageBox.Show("PLEASE CHECK YOUR  SERVER CONNECTION !!!", "error message", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End Try

        DataGridView1.Visible = True
    End Sub

    Private Sub ButtonEDIT_Click(sender As Object, e As EventArgs) Handles ButtonEDIT.Click
        Dim cmd As MySqlCommand
        con.Open()
        Try
            cmd = con.CreateCommand
            cmd.CommandText = "Update tablethermo1 set ID_NUMBER = @ID_NUMBER, PHONE_NO=@PHONE_NO,FIRST_NAME=@FIRST_NAME,SURNAME=@SURNAME,AGE=@AGE, GENDER=@GENDER, TEMPERATURE=@TEMPERATURE Where ID_NUMBER=@ID_NUMBER;"
            cmd.Parameters.AddWithValue("@ID_NUMBER", ID_NUMBERTextBox.Text)
            cmd.Parameters.AddWithValue("@PHONE_NO", PHONE_NOTextBox.Text)
            cmd.Parameters.AddWithValue("@AGE", AGETextBox.Text)
            cmd.Parameters.AddWithValue("@TEMPERATURE", TEMPERATURETextBox.Text)
            cmd.Parameters.AddWithValue("@COUNTY", COUNTYcomboBox.Text)
            cmd.Parameters.AddWithValue("@FIRST_NAME", FIRST_NAMETextBox.Text)
            cmd.Parameters.AddWithValue("@SURNAME", SURNAMETextBox.Text)
            cmd.Parameters.AddWithValue("@GENDER", GENDERcomboBox.Text)
            cmd.ExecuteNonQuery()
            Load()
        Catch ex As Exception
            MessageBox.Show("THE UPDATE IS UNACCEPTED KINDLY CHECK YOUR SERVER CONNECTION!!!", "error message", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End Try
    End Sub
    Private Sub ButtonREFRESH_Click(sender As Object, e As EventArgs) Handles ButtonREFRESH.Click

        Load()
    End Sub
    Private Sub ButtonDELETE_Click(sender As Object, e As EventArgs) Handles ButtonDELETE.Click
        Dim cmd As MySqlCommand
        con.Open()
        Try
            cmd = con.CreateCommand
            cmd.CommandText = "DELETE FROM tablethermo1  Where ID_NUMBER=@ID_NUMBER;"
            cmd.Parameters.AddWithValue("@ID_NUMBER", ID_NUMBERTextBox.Text)
            cmd.Parameters.AddWithValue("@PHONE_NO", PHONE_NOTextBox.Text)
            cmd.Parameters.AddWithValue("@AGE", AGETextBox.Text)
            cmd.Parameters.AddWithValue("@TEMPERATURE", TEMPERATURETextBox.Text)
            cmd.Parameters.AddWithValue("@COUNTY", COUNTYcomboBox.Text)
            cmd.Parameters.AddWithValue("@FIRST_NAME", FIRST_NAMETextBox.Text)
            cmd.Parameters.AddWithValue("@SURNAME", SURNAMETextBox.Text)
            cmd.Parameters.AddWithValue("@GENDER", GENDERcomboBox.Text)
            cmd.ExecuteNonQuery()
            Load()
        Catch ex As Exception
            MessageBox.Show("SELECT A ROW TO DELETE!!!", "error message", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End Try
    End Sub

    Private Sub ButtonVIEW_Click(sender As Object, e As EventArgs) Handles ButtonVIEW.Click
        Try
            DataGridView1.Show()
        Catch ex As Exception
            MessageBox.Show("YOU ARE UNAUTHORIZED ACCESS!!!", "error message", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub PHONE_NOTextBox_KeyPress(sender As Object, e As KeyPressEventArgs) Handles PHONE_NOTextBox.KeyPress
        If Not ((e.KeyChar >= "0" And e.KeyChar <= "9") Or e.KeyChar = vbBack Or e.KeyChar = "+") Then
            MessageBox.Show("invalid entry! enter numbers only", "error message", MessageBoxButtons.OK, MessageBoxIcon.Error)
            e.Handled = True
        End If
    End Sub
    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        FilterData("")
    End Sub
    Public Sub FilterData(valueToSearch As String)
        Dim searchQuery As String = "SELECT * FROM tablethermo1 where VALUES(ID_NUMBER, PHONE_NO,AGE,TEMPERATURE,COUNTY,FIRST_NAME, SURNAME,GENDER) LIKE '%" & valueToSearch & "%'"

        Dim command As New MySqlCommand(searchQuery, con)
        Dim ADAPTER As New MySqlDataAdapter(command)
        Dim table As New DataTable()

        ADAPTER.Fill(table)
        DataGridView1.DataSource = table

    End Sub



    Private Sub Buttonclear_Click(sender As Object, e As EventArgs) Handles Buttonclear.Click
        Load()
    End Sub

    Private Sub TextBox1Search_TextChanged(sender As Object, e As EventArgs) Handles TextBox1Search.TextChanged
        Dim dv As New DataView(DT)
        dv.RowFilter = String.Format("ID_NUMBER LIKE '%{0}%'", TextBox1Search.Text)
        DataGridView1.DataSource = dv

    End Sub
End Class