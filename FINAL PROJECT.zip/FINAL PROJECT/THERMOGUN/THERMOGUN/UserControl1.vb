﻿Public Class UserControl1
    Private Sub UserControl1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Start()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ProgressBar1.Increment(2)
        If ProgressBar1.Value = 100 Then
            Me.Hide()
            WELCOME_TO_DTTRS.Show()
        Else
            WELCOME_TO_DTTRS.Hide()

        End If


    End Sub


End Class
