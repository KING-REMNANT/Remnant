﻿Imports MySql.Data.MySqlClient

Public Class registerForm

    Private Sub registerForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Panel1.BackColor = Color.FromArgb(120, 0, 0, 0)
        ' transparent blue background for panel3
        Panel2.BackColor = Color.FromArgb(100, 17, 97, 238)

        ButtonClose.BackColor = Color.FromArgb(100, 0, 0, 0)
    End Sub

    Private Sub ButtonClose_Click(sender As Object, e As EventArgs) Handles ButtonClose.Click
        ' Application.Exit()
        Me.Visible = False
    End Sub
    Private Sub TextBoxFirstname_Enter(sender As Object, e As EventArgs) Handles TextBoxFirstname.Enter
        LabelFname.ForeColor = Color.Red
    End Sub
    Private Sub TextBoxFirstname_Leave(sender As Object, e As EventArgs) Handles TextBoxFirstname.Leave
        LabelFname.ForeColor = Color.White
    End Sub

    Private Sub TextBoxSurname_Enter(sender As Object, e As EventArgs) Handles TextBoxSurname.Enter
        LabelSurname.ForeColor = Color.Red
    End Sub

    Private Sub TextBoxSurname_Leave(sender As Object, e As EventArgs) Handles TextBoxSurname.Leave
        LabelSurname.ForeColor = Color.White
    End Sub

    Private Sub TextBoxEmail_Enter(sender As Object, e As EventArgs) Handles TextBoxEmail.Enter
        LabelEmail.ForeColor = Color.Red
    End Sub

    Private Sub TextBoxEmail_Leave(sender As Object, e As EventArgs) Handles TextBoxEmail.Leave
        LabelEmail.ForeColor = Color.White
    End Sub

    Private Sub TextBoxpassword_Enter(sender As Object, e As EventArgs) Handles TextBoxpassword.Enter
        LabelPASSWORD1.ForeColor = Color.Red
    End Sub

    Private Sub TextBoxpassword_Leave(sender As Object, e As EventArgs) Handles TextBoxpassword.Leave
        LabelPASSWORD1.ForeColor = Color.White
    End Sub

    Private Sub TextBoxConfirmPassword_Enter(sender As Object, e As EventArgs) Handles TextBoxConfirmPassword.Enter
        LabelPASS2.ForeColor = Color.Red
    End Sub

    Private Sub TextBoxConfirmPassword_Leave(sender As Object, e As EventArgs) Handles TextBoxConfirmPassword.Leave
        LabelPASS2.ForeColor = Color.White
    End Sub
    Private Sub Buttonregister_Click(sender As Object, e As EventArgs) Handles Buttonregister.Click
        LabelGoToSignIn.Visible = True
        ' check if the fields are empty
        ' check if the password = the confirm password
        ' check if the username already exists
        ' get textboxes values
        Try
            Dim first_name As String = TextBoxFirstname.Text
            Dim surname As String = TextBoxSurname.Text
            Dim username As String = TextBoxusername.Text
            Dim email As String = TextBoxEmail.Text
            Dim password As String = TextBoxpassword.Text
            Dim confirmpassword As String = TextBoxConfirmPassword.Text

            If first_name.Trim() = "" Or surname.Trim() = "" Or username.Trim() = "" Or email.Trim() = "" Or password.Trim() = "" Then
                MessageBox.Show("One Or More Fields Are Empty", "Missing Data", MessageBoxButtons.OK, MessageBoxIcon.Stop)
            ElseIf Not String.Equals(password, confirmpassword) Then
                MessageBox.Show("Wrong Confirmation Password", "password Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ElseIf usernameExist(username) Then
                MessageBox.Show("Either the Username or Password Already Exists, Choose Another One", "Duplicate Username", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Else
                ' add the new user
                Dim conn As New MY_CONNECTION()
                Dim command As New MySqlCommand("INSERT INTO `user`(`first_name`, `surname`, `email`, `USERNAME`, `PASSWORD`) VALUES (@FIRST_NAME,@SURNAME,@Email,@username,@password)", conn.getConnection)
                command.Parameters.Add("@first_name", MySqlDbType.VarChar).Value = first_name
                command.Parameters.Add("@surname", MySqlDbType.VarChar).Value = surname
                command.Parameters.Add("@email", MySqlDbType.VarChar).Value = email
                command.Parameters.Add("@username", MySqlDbType.VarChar).Value = username
                command.Parameters.Add("@password", MySqlDbType.VarChar).Value = password
                conn.openConnection()
                If command.ExecuteNonQuery() = 1 Then
                    MsgBox("NEW USER SUCCESSFULLY ADDED!!!")
                    conn.closeConnection()
                End If

            End If
        Catch ex As Exception
            MessageBox.Show("oops sever connection failed", "Registration DB error", MessageBoxButtons.OK)
        End Try

    End Sub
    Public Function usernameExist(ByRef username As String) As Boolean
        Dim con As New MY_CONNECTION()
        Dim table As New DataTable()
        Dim adapter As New MySqlDataAdapter()
        Dim command As New MySqlCommand("SELECT * FROM `user` WHERE `USERNAME`=@username", con.getConnection())
        command.Parameters.Add("username", MySqlDbType.VarChar).Value = username
        adapter.SelectCommand = command
        adapter.Fill(table)
        If table.Rows.Count > 0 Then
            con.openConnection()
            TextBoxFirstname.Clear()
            TextBoxSurname.Clear()
            TextBoxEmail.Clear()
            TextBoxpassword.Clear()
            TextBoxConfirmPassword.Clear()

        Else
            con.closeConnection()
            Return False
        End If
    End Function

    Private Sub LabelGoToSignIn_Click(sender As Object, e As EventArgs) Handles LabelGoToSignIn.Click
        Me.Hide()
        Login_form.Show()

    End Sub
End Class